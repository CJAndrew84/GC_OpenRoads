// =============================================================================
//  Utilities/OpenRoadsHelper.cs  (v2 — terrain sampling for ExistingElevation)
//
//  Static helper class that wraps CifNET SDK calls used by multiple nodes.
//
//  KEY ADDITIONS vs v1
//  -------------------
//  • SampleTerrainAtSection() — queries the active terrain model to populate
//    CrossSectionPoint.ExistingElevation at each feature point offset.
//    This is the source for the "Existing Level" annotation band row.
//  • ExtractCrossSectionAtStation() now automatically calls terrain sampling
//    so downstream nodes don't need to think about it.
//
//  SDK NAMESPACES
//  --------------
//    Bentley.CifNET.SDK / SDK.Edit    — ConsensusConnection
//    Bentley.CifNET.GeometryModel.SDK — Alignment, Corridor, GeometricModel
//    Bentley.CifNET.LinearGeometry    — LinearElement
//    Bentley.TerrainModelNET          — TerrainModel (if available)
//    Bentley.DgnPlatformNET           — DgnFile, DgnModel
//    Bentley.MstnPlatformNET          — Session
// =============================================================================

using Bentley.CifNET.GeometryModel.SDK;
using Bentley.CifNET.GeometryModel.SDK.Edit;
using Bentley.CifNET.LinearGeometry;
using Bentley.CifNET.SDK;
using Bentley.CifNET.SDK.Edit;
using Bentley.DgnPlatformNET;
using Bentley.DgnPlatformNET.Elements;
using Bentley.GeometryNET;
using Bentley.MstnPlatformNET;
using GC_OpenRoads_CrossSections.Models;

namespace GC_OpenRoads_CrossSections.Utilities
{
    public static class OpenRoadsHelper
    {
        // ─────────────────────────────────────────────────────────────────────
        //  UOR helpers
        // ─────────────────────────────────────────────────────────────────────

        public static double UorPerMaster()
        {
            DgnModel model = Session.Instance.GetActiveDgnModel();
            return model.GetModelInfo().UorPerMeter;
        }

        public static double ToUor(double v) => v * UorPerMaster();
        public static double ToMaster(double v) => v / UorPerMaster();

        // ─────────────────────────────────────────────────────────────────────
        //  Connection helpers
        // ─────────────────────────────────────────────────────────────────────

        public static ConsensusConnection GetReadConnection()
        {
            DgnModel model = Session.Instance.GetActiveDgnModel();
            return new ConsensusConnection(model);
        }

        public static ConsensusConnectionEdit GetEditConnection() =>
            ConsensusConnectionEdit.GetActive();

        // ─────────────────────────────────────────────────────────────────────
        //  Alignment helpers
        // ─────────────────────────────────────────────────────────────────────

        public static IReadOnlyList<Alignment> GetAllAlignments()
        {
            using var con = GetReadConnection();
            GeometricModel? gm = con.GetGeometricModel();
            if (gm == null) return Array.Empty<Alignment>();
            return gm.Alignments.OrderBy(a => a.Name).ToList();
        }

        public static Alignment? FindAlignment(string name)
        {
            using var con = GetReadConnection();
            GeometricModel? gm = con.GetGeometricModel();
            return gm?.Alignments.FirstOrDefault(a =>
                string.Equals(a.Name, name, StringComparison.OrdinalIgnoreCase));
        }

        public static (double Start, double End) GetAlignmentStationRange(Alignment alignment)
            => (alignment.StartDistance, alignment.EndDistance);

        // ─────────────────────────────────────────────────────────────────────
        //  Corridor helpers
        // ─────────────────────────────────────────────────────────────────────

        public static IReadOnlyList<Corridor> GetCorridorsForAlignment(string alignmentName)
        {
            using var con = GetReadConnection();
            GeometricModel? gm = con.GetGeometricModel();
            if (gm == null) return Array.Empty<Corridor>();
            return gm.Corridors
                     .Where(c => string.Equals(c.Alignment?.Name, alignmentName,
                                               StringComparison.OrdinalIgnoreCase))
                     .ToList();
        }

        public static Corridor? FindCorridor(string name)
        {
            using var con = GetReadConnection();
            GeometricModel? gm = con.GetGeometricModel();
            return gm?.Corridors.FirstOrDefault(c =>
                string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase));
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Terrain helpers
        //
        //  The active terrain model is retrieved via TerrainModel from the
        //  Bentley.TerrainModelNET assembly.  We query elevation at world XY
        //  positions derived from the alignment offset.
        //
        //  If no terrain is active or the terrain doesn't cover the point, we
        //  leave ExistingElevation null (the annotation band shows "—").
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Samples the active terrain model at each feature point offset along a
        /// section and populates <see cref="CrossSectionPoint.ExistingElevation"/>.
        /// </summary>
        public static void SampleTerrainAtSection(
            Alignment        alignment,
            CrossSectionData section)
        {
            // Get the active terrain model via the CifNET geometric model
            using var con      = GetReadConnection();
            GeometricModel? gm = con.GetGeometricModel();
            if (gm == null) return;

            // Prefer the active terrain; fall back to first available
            var terrain = gm.ActiveTerrain ?? gm.Terrains.FirstOrDefault();
            if (terrain == null) return;

            foreach (var pt in section.Points)
            {
                try
                {
                    // Compute world XY for (station, offset) using the alignment
                    DPoint3d worldPt = alignment.LinearGeometry
                        .GetPointAtDistanceAndOffset(section.Station, pt.Offset);

                    // Sample terrain elevation at that XY
                    double? z = terrain.GetElevationAtPoint(worldPt.X, worldPt.Y);
                    if (z.HasValue)
                        pt.ExistingElevation = z.Value;
                }
                catch
                {
                    // If sampling fails for any point, leave ExistingElevation null
                }
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Cross-section data extraction
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Extracts cross-section data for a corridor at evenly-spaced stations,
        /// also sampling terrain for existing elevations where available.
        /// </summary>
        public static List<CrossSectionData> ExtractCrossSections(
            Corridor corridor,
            double   startStation,
            double   endStation,
            double   interval,
            Alignment? alignmentForTerrain = null)
        {
            if (interval <= 0) throw new ArgumentOutOfRangeException(nameof(interval));
            var results = new List<CrossSectionData>();

            double csStart = Math.Max(startStation, corridor.StartDistance);
            double csEnd   = Math.Min(endStation,   corridor.EndDistance);

            for (double station = csStart; station <= csEnd + 1e-6; station += interval)
            {
                double clamped = Math.Min(station, csEnd);
                var section = ExtractCrossSectionAtStation(
                    corridor, clamped, alignmentForTerrain);
                if (section != null)
                    results.Add(section);
                if (Math.Abs(clamped - csEnd) < 1e-6) break;
            }

            return results;
        }

        /// <summary>
        /// Extracts cross-section data at a single station.
        /// Populates ExistingElevation when <paramref name="alignmentForTerrain"/> is provided.
        /// </summary>
        public static CrossSectionData? ExtractCrossSectionAtStation(
            Corridor   corridor,
            double     station,
            Alignment? alignmentForTerrain = null)
        {
            if (station < corridor.StartDistance - 1e-6 ||
                station > corridor.EndDistance   + 1e-6)
                return null;

            var section = new CrossSectionData
            {
                Station      = station,
                StationLabel = FormatStation(station)
            };

            try
            {
                // Retrieve corridor section points via CifNET SDK
                var rawPoints = corridor.GetSectionPoints(station);

                foreach (var rp in rawPoints)
                {
                    section.Points.Add(new CrossSectionPoint
                    {
                        FeatureName = rp.CorridorFeatureName ?? string.Empty,
                        PointCode   = rp.FeaturePoint        ?? string.Empty,
                        Offset      = rp.Offset,
                        Elevation   = rp.Elevation,
                        CutFill     = rp.CutFill
                    });
                }

                section.Points.Sort((a, b) => a.Offset.CompareTo(b.Offset));

                // Populate ExistingElevation from terrain model
                if (alignmentForTerrain != null)
                    SampleTerrainAtSection(alignmentForTerrain, section);
            }
            catch (Exception ex)
            {
                section.Points.Add(new CrossSectionPoint
                {
                    PointCode = $"ERROR: {ex.Message}",
                    Offset    = 0,
                    Elevation = 0
                });
            }

            return section;
        }

        // ─────────────────────────────────────────────────────────────────────
        //  Station formatting
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>Formats a station value as "K+CCC.DDD", e.g. "1+234.567".</summary>
        public static string FormatStation(double stationMetres)
        {
            int km     = (int)(stationMetres / 1000.0);
            double rem = stationMetres - km * 1000.0;
            return $"{km}+{rem:000.000}";
        }

        // ─────────────────────────────────────────────────────────────────────
        //  World-coordinate transform
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Converts a section's point list to world 3-D coordinates using the
        /// alignment's LinearGeometry.GetPointAtDistanceAndOffset().
        /// </summary>
        public static DPoint3d[] SectionPointsToWorldCoords(
            Alignment        alignment,
            CrossSectionData section)
        {
            var worldPoints = new DPoint3d[section.Points.Count];
            for (int i = 0; i < section.Points.Count; i++)
            {
                var pt    = section.Points[i];
                var world = alignment.LinearGeometry
                    .GetPointAtDistanceAndOffset(section.Station, pt.Offset);
                worldPoints[i] = new DPoint3d(world.X, world.Y, pt.Elevation);
            }
            return worldPoints;
        }
    }
}
