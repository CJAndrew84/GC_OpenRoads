// =============================================================================
//  GC_OpenRoads_CrossSections — AddIn entry point
//
//  Every node type added to the project must be registered here.
//  GC discovers this class via the [AddIn] attribute and calls Initialize().
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using GC_OpenRoads_CrossSections.Nodes;

namespace GC_OpenRoads_CrossSections
{
    [AddIn(GuidString = "A1B2C3D4-E5F6-7890-ABCD-EF1234567890",
           Description = "OpenRoads Cross Section tools for GenerativeComponents")]
    public class AddInMain : AddIn
    {
        protected override void Initialize()
        {
            NodeTypeRegistry.Register<ORAlignmentNode>();
            NodeTypeRegistry.Register<ORCorridorNode>();
            NodeTypeRegistry.Register<ORCrossSectionDataNode>();
            NodeTypeRegistry.Register<ORCrossSectionGeometryNode>();
            NodeTypeRegistry.Register<ORAnnotationBandNode>();          // annotation box
            NodeTypeRegistry.Register<ORNamedBoundaryNode>();
            NodeTypeRegistry.Register<ORDrawingProductionNode>();
            NodeTypeRegistry.Register<ORCrossSectionSheetLayoutNode>();
        }
    }
}
