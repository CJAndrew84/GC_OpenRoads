// =============================================================================
//  Nodes/ORAlignmentNode.cs
//
//  GC Node Type: "ORAlignment"
//
//  PURPOSE
//  -------
//  Lets the user select an OpenRoads horizontal alignment from the active DGN
//  and exposes its key properties (name, start/end station, length) as GC
//  output ports that feed into downstream nodes.
//
//  GC API CONCEPTS USED
//  --------------------
//  • GenerativeComponentsNode  — base class for all custom GC nodes
//  • [NodeType]                — marks the class as a GC node
//  • [Technique]               — marks a method as a GC technique (update path)
//  • [Input] / [Output]        — property-level attributes for port visibility
//  • NodeUpdateResult          — what a technique returns to tell GC pass/fail
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.GenerativeComponents.GCTransactionModel;
using Bentley.CifNET.GeometryModel.SDK;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    // -------------------------------------------------------------------------
    /// <summary>
    /// GC node that wraps an OpenRoads horizontal alignment.
    /// Place one of these in a GC graph to provide the alignment reference that
    /// all other ORD cross-section nodes depend upon.
    /// </summary>
    // -------------------------------------------------------------------------
    [NodeType(
        Name        = "ORAlignment",
        Category    = "OpenRoads|Geometry",
        Description = "References an OpenRoads Designer horizontal alignment and " +
                      "exposes its station range.")]
    public class ORAlignmentNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUT PROPERTIES
        // =====================================================================

        /// <summary>
        /// Name of the alignment in the active DGN file.
        /// Must match the ORD Feature Name exactly (case-insensitive).
        /// </summary>
        [Input(Description = "Name of the horizontal alignment in the active DGN.")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        // =====================================================================
        //  OUTPUT PROPERTIES
        // =====================================================================

        [Output(Description = "Start chainage of the alignment (metres).")]
        public double StartStation { get; private set; }

        [Output(Description = "End chainage of the alignment (metres).")]
        public double EndStation { get; private set; }

        [Output(Description = "Total length of the alignment (metres).")]
        public double Length { get; private set; }

        /// <summary>
        /// A dropdown list of all alignment names in the active model, populated
        /// at update time so users can pick from a list rather than type.
        /// </summary>
        [Output(Description = "All alignment names found in the active DGN model.")]
        public IReadOnlyList<string> AvailableAlignments { get; private set; }
            = Array.Empty<string>();

        // Internal SDK object — not exposed as a GC port, but passed to child
        // nodes as a typed reference through the GC transaction model.
        internal Alignment? SDKAlignment { get; private set; }

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        /// <summary>
        /// Default technique: resolves the named alignment and populates outputs.
        /// </summary>
        [Technique(Description = "Resolves the named alignment and reads its station range.")]
        public NodeUpdateResult ByName()
        {
            // Always refresh the available-alignments list
            AvailableAlignments = OpenRoadsHelper
                .GetAllAlignments()
                .Select(a => a.Name ?? "(unnamed)")
                .ToList();

            if (string.IsNullOrWhiteSpace(AlignmentName))
                return NodeUpdateResult.CustomFailure(
                    "AlignmentName is empty. Set it to the name of a horizontal alignment.");

            Alignment? alignment = OpenRoadsHelper.FindAlignment(AlignmentName);
            if (alignment == null)
                return NodeUpdateResult.CustomFailure(
                    $"No alignment named '{AlignmentName}' found in the active model. " +
                    $"Available: {string.Join(", ", AvailableAlignments)}");

            SDKAlignment  = alignment;
            (StartStation, EndStation) = OpenRoadsHelper.GetAlignmentStationRange(alignment);
            Length = EndStation - StartStation;

            return NodeUpdateResult.Success;
        }

        /// <summary>
        /// Overload: use start/end stations provided directly (useful when the
        /// user wants to work on a sub-range without changing AlignmentName).
        /// </summary>
        [Technique(Description = "Resolves the named alignment and applies custom station limits.")]
        public NodeUpdateResult ByNameWithStationOverride(
            double customStartStation,
            double customEndStation)
        {
            NodeUpdateResult baseResult = ByName();
            if (!baseResult.IsSuccess) return baseResult;

            if (customStartStation >= customEndStation)
                return NodeUpdateResult.CustomFailure(
                    "customStartStation must be less than customEndStation.");

            StartStation = Math.Max(customStartStation, StartStation);
            EndStation   = Math.Min(customEndStation,   EndStation);
            Length       = EndStation - StartStation;

            return NodeUpdateResult.Success;
        }
    }
}
