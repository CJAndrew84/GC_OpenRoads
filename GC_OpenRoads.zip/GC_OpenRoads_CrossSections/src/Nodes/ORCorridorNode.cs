// =============================================================================
//  Nodes/ORCorridorNode.cs
//
//  GC Node Type: "ORCorridor"
//
//  PURPOSE
//  -------
//  Selects an OpenRoads corridor and exposes it as a typed GC port for use by
//  the cross-section data extraction node.  Accepts either:
//    a) an alignment node + automatic lookup of the first associated corridor, or
//    b) an explicit corridor name.
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.CifNET.GeometryModel.SDK;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORCorridor",
        Category    = "OpenRoads|Geometry",
        Description = "References an OpenRoads Designer corridor model.")]
    public class ORCorridorNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "Explicit corridor name. If empty, the first corridor " +
                             "associated with AlignmentName is used.")]
        public string CorridorName
        {
            get => _corridorName;
            set { _corridorName = value; NotifyPropertyChanged(); }
        }
        private string _corridorName = string.Empty;

        [Input(Description = "Alignment name. Used when CorridorName is empty to find " +
                             "the associated corridor automatically.")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        // =====================================================================
        //  OUTPUTS
        // =====================================================================

        [Output(Description = "Resolved corridor name.")]
        public string ResolvedCorridorName { get; private set; } = string.Empty;

        [Output(Description = "Start chainage covered by this corridor (metres).")]
        public double StartStation { get; private set; }

        [Output(Description = "End chainage covered by this corridor (metres).")]
        public double EndStation { get; private set; }

        [Output(Description = "Names of all corridors found in the active model.")]
        public IReadOnlyList<string> AvailableCorridors { get; private set; }
            = Array.Empty<string>();

        internal Corridor? SDKCorridor { get; private set; }

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(Description = "Resolves the corridor by name or via the alignment.")]
        public NodeUpdateResult ByNameOrAlignment()
        {
            // Refresh available-corridors list for the UI
            using var con = OpenRoadsHelper.GetReadConnection();
            var gm = con.GetGeometricModel();
            AvailableCorridors = gm?.Corridors
                                    .Select(c => c.Name ?? "(unnamed)")
                                    .OrderBy(n => n)
                                    .ToList()
                                 ?? new List<string>();

            Corridor? corridor = null;

            if (!string.IsNullOrWhiteSpace(CorridorName))
            {
                corridor = OpenRoadsHelper.FindCorridor(CorridorName);
                if (corridor == null)
                    return NodeUpdateResult.CustomFailure(
                        $"No corridor named '{CorridorName}' found. " +
                        $"Available: {string.Join(", ", AvailableCorridors)}");
            }
            else if (!string.IsNullOrWhiteSpace(AlignmentName))
            {
                var corridors = OpenRoadsHelper.GetCorridorsForAlignment(AlignmentName);
                if (!corridors.Any())
                    return NodeUpdateResult.CustomFailure(
                        $"No corridors found for alignment '{AlignmentName}'.");
                corridor = corridors.First();
            }
            else
            {
                return NodeUpdateResult.CustomFailure(
                    "Provide either CorridorName or AlignmentName.");
            }

            SDKCorridor           = corridor;
            ResolvedCorridorName  = corridor.Name ?? string.Empty;
            StartStation          = corridor.StartDistance;
            EndStation            = corridor.EndDistance;

            return NodeUpdateResult.Success;
        }
    }
}
