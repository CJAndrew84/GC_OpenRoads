// =============================================================================
//  Nodes/ORCrossSectionGeometryNode.cs  (v2 — vertical exaggeration + band origin)
// =============================================================================
//
//  SCALE MODEL
//  -----------
//  HorizontalScaleDenominator  e.g. 200  →  1 real metre = 1/200 sheet-unit
//  VerticalExaggerationFactor  e.g. 2    →  vertical drawn 2× taller
//    EffectiveVerticalDenominator = HorizontalScaleDenominator / VerticalExaggerationFactor
//    e.g.  200 / 2 = 100  (drawing is V 1:100 while H 1:200)
//
//  Sheet coords:
//    sheetX = OriginX + (offset    - refOffset) / HorizontalScaleDenominator
//    sheetY = OriginY + (elevation - refElev)   / EffectiveVerticalDenominator

using Bentley.DgnPlatformNET;
using Bentley.DgnPlatformNET.Elements;
using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.GeometryNET;
using Bentley.MstnPlatformNET;
using GC_OpenRoads_CrossSections.Models;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORCrossSectionGeometry",
        Category    = "OpenRoads|CrossSections",
        Description = "Converts cross-section point data into drawable GC geometry. " +
                      "Supports independent horizontal and vertical scales with a " +
                      "vertical exaggeration factor. Outputs AnnotationBandTopY " +
                      "for the ORAnnotationBand node.")]
    public class ORCrossSectionGeometryNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "Cross-section data from an ORCrossSectionData node.")]
        public CrossSectionData? SectionData
        {
            get => _sectionData;
            set { _sectionData = value; NotifyPropertyChanged(); }
        }
        private CrossSectionData? _sectionData;

        [Input(Description = "Alignment name — for world-coord transform in PlaceInDgn().")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        // ------------------------------------------------------------------
        //  Scale inputs
        // ------------------------------------------------------------------

        [Input(Description =
            "Horizontal scale denominator. 200 → drawing is 1:200 horizontally. " +
            "One real metre = 1/200 of a sheet master-unit.")]
        public double HorizontalScaleDenominator
        {
            get => _hDenom;
            set { _hDenom = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private double _hDenom = 200.0;

        [Input(Description =
            "Vertical exaggeration factor relative to horizontal scale.\n" +
            "  1.0 = true scale (same denominator as horizontal).\n" +
            "  2.0 = vertical twice as tall (effective V denom = H/2 = 1:100).\n" +
            "  5.0 = five-times exaggeration (effective V denom = H/5 = 1:40).\n" +
            "The effective vertical denominator is reported as an output.")]
        public double VerticalExaggerationFactor
        {
            get => _vExag;
            set { _vExag = Math.Max(value, 0.1); NotifyPropertyChanged(); }
        }
        private double _vExag = 1.0;

        // ------------------------------------------------------------------
        //  Position inputs
        // ------------------------------------------------------------------

        [Input(Description = "Sheet lower-left origin X (master units). " +
                             "Driven from ORCrossSectionSheetLayout.SectionOriginX.")]
        public double OriginX
        {
            get => _ox;
            set { _ox = value; NotifyPropertyChanged(); }
        }
        private double _ox;

        [Input(Description = "Sheet lower-left origin Y (master units). " +
                             "Driven from ORCrossSectionSheetLayout.SectionOriginY. " +
                             "This is the BOTTOM of the profile area, ABOVE the annotation band.")]
        public double OriginY
        {
            get => _oy;
            set { _oy = value; NotifyPropertyChanged(); }
        }
        private double _oy;

        [Input(Description = "Gap between the lowest profile point and the annotation band " +
                             "top edge (master units). Default 2.")]
        public double ProfileBottomClearance
        {
            get => _botClear;
            set { _botClear = Math.Max(value, 0); NotifyPropertyChanged(); }
        }
        private double _botClear = 2.0;

        [Input(Description = "Tick mark half-height at each feature point (master units). " +
                             "Ticks straddle the profile line by this amount above and below.")]
        public double TickHalfHeight
        {
            get => _tickH;
            set { _tickH = Math.Max(value, 0); NotifyPropertyChanged(); }
        }
        private double _tickH = 1.0;

        [Input(Description = "Draw a horizontal datum line at the reference elevation.")]
        public bool DrawDatumLine
        {
            get => _drawDatum;
            set { _drawDatum = value; NotifyPropertyChanged(); }
        }
        private bool _drawDatum = true;

        [Input(Description = "Draw vertical drop lines from each feature point " +
                             "down to the datum line.")]
        public bool DrawVerticalDropLines
        {
            get => _drawDrops;
            set { _drawDrops = value; NotifyPropertyChanged(); }
        }
        private bool _drawDrops = true;

        // =====================================================================
        //  OUTPUTS — Scale reporting
        // =====================================================================

        [Output(Description = "Effective vertical scale denominator after exaggeration. " +
                              "e.g. H=200, exag=2 → 100 (i.e. V is 1:100).")]
        public double EffectiveVerticalScaleDenominator { get; private set; }

        [Output(Description = "Human-readable scale string, e.g. 'H 1:200  /  V 1:100  (×2 V.E.)'.")]
        public string ScaleLabel { get; private set; } = string.Empty;

        // =====================================================================
        //  OUTPUTS — Geometry
        // =====================================================================

        [Output(Description = "Proposed design profile polyline points in sheet space.")]
        public DPoint3d[] DesignProfilePoints { get; private set; } = Array.Empty<DPoint3d>();

        [Output(Description = "Existing ground profile polyline in sheet space. " +
                              "Empty if no terrain data is present in the section.")]
        public DPoint3d[] ExistingProfilePoints { get; private set; } = Array.Empty<DPoint3d>();

        [Output(Description = "Paired tick mark points (bottom, top alternating) " +
                              "for each feature point.")]
        public DPoint3d[] TickMarkPoints { get; private set; } = Array.Empty<DPoint3d>();

        [Output(Description = "Paired drop-line points (feature level, datum level alternating).")]
        public DPoint3d[] DropLinePoints { get; private set; } = Array.Empty<DPoint3d>();

        [Output(Description = "Two points (left, right) for the horizontal datum line.")]
        public DPoint3d[] DatumLinePoints { get; private set; } = Array.Empty<DPoint3d>();

        // =====================================================================
        //  OUTPUTS — Annotation wiring
        // =====================================================================

        [Output(Description = "Feature point codes left-to-right (e.g. 'DAYLIGHT_L','EOP_L','CL'…).")]
        public IReadOnlyList<string> AnnotationLabels { get; private set; }
            = Array.Empty<string>();

        [Output(Description = "Sheet-space X centre for each feature point column. " +
                              "Feed directly into ORAnnotationBand.ColumnCentresX.")]
        public IReadOnlyList<double> ColumnCentreX { get; private set; }
            = Array.Empty<double>();

        [Output(Description = "Y coordinate of the annotation band's top edge. " +
                              "= lowest profile point - ProfileBottomClearance. " +
                              "Feed into ORAnnotationBand.BandTopY.")]
        public double AnnotationBandTopY { get; private set; }

        [Output(Description = "X of the leftmost feature point (left edge of section).")]
        public double ProfileLeftX { get; private set; }

        [Output(Description = "X of the rightmost feature point (right edge of section).")]
        public double ProfileRightX { get; private set; }

        [Output(Description = "Total profile width in sheet units.")]
        public double ProfileWidth { get; private set; }

        [Output(Description = "Total profile height in sheet units (datum to highest point).")]
        public double ProfileHeight { get; private set; }

        [Output(Description = "Sheet X of the centre line.")]
        public double CentreLineX { get; private set; }

        [Output(Description = "Sheet Y of the datum line.")]
        public double DatumY { get; private set; }

        [Output(Description = "Station label, e.g. '1+234.567'.")]
        public string StationLabel { get; private set; } = string.Empty;

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(IsDefault = true,
                   Description =
                       "Computes all sheet-space geometry using HorizontalScaleDenominator " +
                       "and VerticalExaggerationFactor. No DGN writes.")]
        public NodeUpdateResult Build2DProfile()
        {
            if (SectionData == null || SectionData.Points.Count == 0)
                return NodeUpdateResult.CustomFailure(
                    "SectionData is null or empty. Connect an ORCrossSectionData node.");

            // ------------------------------------------------------------------
            //  Effective scales
            // ------------------------------------------------------------------
            EffectiveVerticalScaleDenominator =
                HorizontalScaleDenominator / VerticalExaggerationFactor;

            ScaleLabel = (Math.Abs(VerticalExaggerationFactor - 1.0) < 1e-6)
                ? $"1:{HorizontalScaleDenominator:G} (true scale)"
                : $"H 1:{HorizontalScaleDenominator:G}  /  " +
                  $"V 1:{EffectiveVerticalScaleDenominator:G}  " +
                  $"(×{VerticalExaggerationFactor:G} V.E.)";

            var pts = SectionData.Points;

            // Reference: prefer CL, fall back to offset=0 / minimum elevation
            var clPt     = pts.FirstOrDefault(p =>
                               p.PointCode.Equals("CL", StringComparison.OrdinalIgnoreCase));
            double refOff  = clPt?.Offset    ?? 0.0;
            double refElev = clPt?.Elevation ?? pts.Min(p => p.Elevation);

            // Datum sits at OriginY (refElev → OriginY)
            DatumY = _oy;

            // ------------------------------------------------------------------
            //  Build arrays
            // ------------------------------------------------------------------
            var profile    = new List<DPoint3d>(pts.Count);
            var ticks      = new List<DPoint3d>(pts.Count * 2);
            var drops      = new List<DPoint3d>(pts.Count * 2);
            var labels     = new List<string>(pts.Count);
            var colCentres = new List<double>(pts.Count);

            double minX = double.MaxValue, maxX = double.MinValue;
            double minY = double.MaxValue, maxY = double.MinValue;

            foreach (var pt in pts)
            {
                double sx = SX(pt.Offset, refOff);
                double sy = SY(pt.Elevation, refElev);

                profile.Add(Pt(sx, sy));
                ticks.Add(Pt(sx, sy - TickHalfHeight));
                ticks.Add(Pt(sx, sy + TickHalfHeight));
                drops.Add(Pt(sx, sy));
                drops.Add(Pt(sx, DatumY));
                labels.Add(pt.PointCode);
                colCentres.Add(sx);

                if (sx < minX) minX = sx;
                if (sx > maxX) maxX = sx;
                if (sy < minY) minY = sy;
                if (sy > maxY) maxY = sy;
            }

            DesignProfilePoints = profile.ToArray();
            TickMarkPoints      = ticks.ToArray();
            DropLinePoints      = DrawVerticalDropLines ? drops.ToArray() : Array.Empty<DPoint3d>();
            AnnotationLabels    = labels;
            ColumnCentreX       = colCentres;
            ProfileLeftX        = minX;
            ProfileRightX       = maxX;
            ProfileWidth        = maxX - minX;
            ProfileHeight       = maxY - DatumY;
            CentreLineX         = SX(refOff, refOff);
            StationLabel        = SectionData.StationLabel;

            DatumLinePoints = DrawDatumLine
                ? new[] { Pt(minX, DatumY), Pt(maxX, DatumY) }
                : Array.Empty<DPoint3d>();

            // Annotation band top = lowest profile point minus clearance
            AnnotationBandTopY = minY - ProfileBottomClearance;

            // ------------------------------------------------------------------
            //  Existing ground profile
            // ------------------------------------------------------------------
            ExistingProfilePoints = pts
                .Where(p => p.ExistingElevation.HasValue)
                .Select(p => Pt(SX(p.Offset, refOff), SY(p.ExistingElevation!.Value, refElev)))
                .ToArray();
            if (ExistingProfilePoints.Length < 2)
                ExistingProfilePoints = Array.Empty<DPoint3d>();

            return NodeUpdateResult.Success;
        }

        [Technique(Description = "Computes geometry AND places elements in the active DGN model.")]
        public NodeUpdateResult PlaceInDgn()
        {
            var r = Build2DProfile();
            if (!r.IsSuccess) return r;

            DgnModel m = Session.Instance.GetActiveDgnModel();

            if (DesignProfilePoints.Length  >= 2) new LineStringElement(m, null, DesignProfilePoints).AddToModel();
            if (ExistingProfilePoints.Length >= 2) new LineStringElement(m, null, ExistingProfilePoints).AddToModel();
            if (DatumLinePoints.Length == 2)       LineElement.Create(m, DatumLinePoints[0], DatumLinePoints[1]).AddToModel();

            for (int i = 0; i < TickMarkPoints.Length - 1; i += 2)
                LineElement.Create(m, TickMarkPoints[i], TickMarkPoints[i + 1]).AddToModel();
            for (int i = 0; i < DropLinePoints.Length - 1; i += 2)
                LineElement.Create(m, DropLinePoints[i], DropLinePoints[i + 1]).AddToModel();

            return NodeUpdateResult.Success;
        }

        // =====================================================================
        //  HELPERS
        // =====================================================================

        private double SX(double offset,    double refOff)  => _ox + (offset    - refOff)  / HorizontalScaleDenominator;
        private double SY(double elevation, double refElev) => _oy + (elevation - refElev) / EffectiveVerticalScaleDenominator;
        private static DPoint3d Pt(double x, double y)     => new(x, y, 0);
    }
}
