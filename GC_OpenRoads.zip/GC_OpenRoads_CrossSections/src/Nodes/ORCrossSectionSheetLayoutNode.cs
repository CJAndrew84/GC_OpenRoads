// =============================================================================
//  Nodes/ORCrossSectionSheetLayoutNode.cs
//
//  GC Node Type: "ORCrossSectionSheetLayout"
//
//  PURPOSE
//  -------
//  This is where GC's parametric power shines for drawing production.
//  Given a list of CrossSectionData objects, this node computes:
//    • The 2-D sheet position (X, Y) for every section
//    • Which sheet each section belongs to
//    • Section bounding boxes for clearance checking
//    • Grid line positions for the vertical/horizontal datum lines
//
//  The outputs feed back into ORCrossSectionGeometryNode (one per section)
//  and can also drive GC text nodes for labels and dimension nodes for
//  annotations.
//
//  PARAMETRIC BENEFIT
//  ------------------
//  Changing StationInterval in the data node causes GC to recompute this
//  layout node automatically.  The section count changes, sheets are
//  re-arranged, and all downstream geometry nodes update.  No manual
//  re-running of the ORD "Create Drawing" wizard is needed for layout
//  experiments.
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.GeometryNET;
using GC_OpenRoads_CrossSections.Models;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORCrossSectionSheetLayout",
        Category    = "OpenRoads|DrawingProduction",
        Description = "Parametrically arranges cross sections onto sheets. " +
                      "Accounts for annotation band height below each section so " +
                      "cell partitioning is correct when bands are used.")]
    public class ORCrossSectionSheetLayoutNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "List of cross-section data from ORCrossSectionData node.")]
        public IReadOnlyList<CrossSectionData> AllSections
        {
            get => _allSections;
            set { _allSections = value; NotifyPropertyChanged(); }
        }
        private IReadOnlyList<CrossSectionData> _allSections = Array.Empty<CrossSectionData>();

        [Input(Description = "Sheet width in master units (e.g. 594 for A1 @ 1:1).")]
        public double SheetWidth
        {
            get => _sheetWidth;
            set { _sheetWidth = Math.Max(value, 10); NotifyPropertyChanged(); }
        }
        private double _sheetWidth = 594.0;

        [Input(Description = "Sheet height in master units.")]
        public double SheetHeight
        {
            get => _sheetHeight;
            set { _sheetHeight = Math.Max(value, 10); NotifyPropertyChanged(); }
        }
        private double _sheetHeight = 420.0;

        [Input(Description = "Number of columns of sections per sheet.")]
        public int ColumnsPerSheet
        {
            get => _columns;
            set { _columns = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private int _columns = 2;

        [Input(Description = "Number of sections per column.")]
        public int RowsPerColumn
        {
            get => _rows;
            set { _rows = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private int _rows = 4;

        [Input(Description = "Left margin of the sheet (master units).")]
        public double MarginLeft   { get => _mLeft;   set { _mLeft   = value; NotifyPropertyChanged(); } }
        private double _mLeft = 20;

        [Input(Description = "Right margin of the sheet (master units).")]
        public double MarginRight  { get => _mRight;  set { _mRight  = value; NotifyPropertyChanged(); } }
        private double _mRight = 20;

        [Input(Description = "Top margin of the sheet (master units).")]
        public double MarginTop    { get => _mTop;    set { _mTop    = value; NotifyPropertyChanged(); } }
        private double _mTop = 30;

        [Input(Description = "Bottom margin of the sheet (master units).")]
        public double MarginBottom { get => _mBottom; set { _mBottom = value; NotifyPropertyChanged(); } }
        private double _mBottom = 20;

        [Input(Description = "Horizontal gap between sections (master units).")]
        public double GapHorizontal { get => _gapH; set { _gapH = value; NotifyPropertyChanged(); } }
        private double _gapH = 10;

        [Input(Description = "Vertical gap between sections (master units).")]
        public double GapVertical   { get => _gapV; set { _gapV = value; NotifyPropertyChanged(); } }
        private double _gapV = 10;

        [Input(Description = "Horizontal drawing scale denominator (e.g. 200 for 1:200).")]
        public double HorizontalScale
        {
            get => _hScale;
            set { _hScale = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private double _hScale = 200.0;

        [Input(Description = "Vertical exaggeration factor (1.0 = true scale, 2.0 = twice as tall). " +
                             "Must match the value used in ORCrossSectionGeometry nodes.")]
        public double VerticalExaggerationFactor
        {
            get => _vExag;
            set { _vExag = Math.Max(value, 0.1); NotifyPropertyChanged(); }
        }
        private double _vExag = 1.0;

        [Input(Description =
            "Height of the annotation band below each section (master units). " +
            "The layout reserves this space below each section cell so that " +
            "ORAnnotationBand elements do not overlap the profile above. " +
            "Set to (NumberOfEnabledRows × DefaultRowHeight + LabelColumnWidth-related clearance). " +
            "Default 30 (= 6 rows × 5 units each).")]
        public double AnnotationBandHeight
        {
            get => _bandH;
            set { _bandH = Math.Max(value, 0); NotifyPropertyChanged(); }
        }
        private double _bandH = 30.0;

        // =====================================================================
        //  OUTPUTS
        // =====================================================================

        [Output(Description = "Layout record for each cross section.")]
        public IReadOnlyList<CrossSectionLayout> Layouts { get; private set; }
            = Array.Empty<CrossSectionLayout>();

        [Output(Description = "Total number of sheets required.")]
        public int TotalSheets { get; private set; }

        [Output(Description = "Sheet origin points (one per sheet, lower-left corner).")]
        public IReadOnlyList<DPoint3d> SheetOrigins { get; private set; }
            = Array.Empty<DPoint3d>();

        [Output(Description = "Width of each section cell on the sheet (profile area only).")]
        public double CellWidth { get; private set; }

        [Output(Description = "Height of each section cell on the sheet (profile area only, " +
                              "NOT including the annotation band).")]
        public double CellProfileHeight { get; private set; }

        [Output(Description = "Total cell height including annotation band.")]
        public double CellTotalHeight { get; private set; }

        [Output(Description = "Station labels for all sections in sheet order.")]
        public IReadOnlyList<string> StationLabels { get; private set; }
            = Array.Empty<string>();

        [Output(Description = "X origin for each section's profile area (left edge).")]
        public IReadOnlyList<double> SectionOriginX { get; private set; }
            = Array.Empty<double>();

        [Output(Description = "Y origin for each section's PROFILE area " +
                              "(bottom of profile, immediately above the annotation band).")]
        public IReadOnlyList<double> SectionOriginY { get; private set; }
            = Array.Empty<double>();

        [Output(Description = "Y of the top of the annotation band for each section " +
                              "(= SectionOriginY - ProfileBottomClearance from geometry node, " +
                              "but here pre-computed as SectionOriginY for simplicity — " +
                              "the geometry node subtracts its own clearance).")]
        public IReadOnlyList<double> AnnotationBandTopY { get; private set; }
            = Array.Empty<double>();

        [Output(Description = "Sheet index (0-based) for each section.")]
        public IReadOnlyList<int> SectionSheetIndex { get; private set; }
            = Array.Empty<int>();

        [Output(Description = "Human-readable scale string passed from layout to drawing title block.")]
        public string ScaleLabel { get; private set; } = string.Empty;

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(IsDefault = true,
                   Description = "Computes the sheet layout for all cross sections, " +
                                 "reserving AnnotationBandHeight below each profile area.")]
        public NodeUpdateResult ComputeLayout()
        {
            if (AllSections == null || AllSections.Count == 0)
                return NodeUpdateResult.CustomFailure(
                    "AllSections is empty. Connect an ORCrossSectionData node.");

            int sectionsPerSheet = ColumnsPerSheet * RowsPerColumn;
            TotalSheets = (int)Math.Ceiling((double)AllSections.Count / sectionsPerSheet);

            // Available drawing area per sheet (inside margins)
            double drawW = SheetWidth  - MarginLeft - MarginRight;
            double drawH = SheetHeight - MarginTop  - MarginBottom;

            // Total cell height = profile area + annotation band
            double totalCellH  = (drawH - GapVertical   * (RowsPerColumn   - 1)) / RowsPerColumn;
            double profileCellH = totalCellH - AnnotationBandHeight;

            if (profileCellH <= 5)
                return NodeUpdateResult.CustomFailure(
                    $"AnnotationBandHeight ({AnnotationBandHeight}) leaves only {profileCellH:F1} " +
                    $"units for the profile area. Reduce AnnotationBandHeight, increase SheetHeight, " +
                    $"or reduce RowsPerColumn.");

            CellWidth        = (drawW - GapHorizontal * (ColumnsPerSheet - 1)) / ColumnsPerSheet;
            CellProfileHeight = profileCellH;
            CellTotalHeight   = totalCellH;

            double vEffDenom = HorizontalScale / VerticalExaggerationFactor;
            ScaleLabel = (Math.Abs(VerticalExaggerationFactor - 1.0) < 1e-6)
                ? $"1:{HorizontalScale:G}"
                : $"H 1:{HorizontalScale:G}  /  V 1:{vEffDenom:G}  (×{VerticalExaggerationFactor:G} V.E.)";

            var layouts       = new List<CrossSectionLayout>();
            var sheetOrigins  = new List<DPoint3d>();
            var labelList     = new List<string>();
            var oxList        = new List<double>();
            var oyList        = new List<double>();
            var bandTopList   = new List<double>();
            var sheetIdxList  = new List<int>();

            for (int i = 0; i < AllSections.Count; i++)
            {
                int sheetIdx   = i / sectionsPerSheet;
                int posOnSheet = i % sectionsPerSheet;
                int col        = posOnSheet % ColumnsPerSheet;
                int row        = posOnSheet / ColumnsPerSheet;

                // Stack sheets side-by-side in GC space for easy preview
                if (sheetOrigins.Count <= sheetIdx)
                    sheetOrigins.Add(new DPoint3d(sheetIdx * (SheetWidth + 50), 0, 0));

                // X origin of the profile cell (left edge, NOT shifted for label column —
                // that offset is handled inside ORAnnotationBand using LabelColumnWidth)
                double ox = sheetOrigins[sheetIdx].X + MarginLeft
                            + col * (CellWidth + GapHorizontal);

                // Y origin = BOTTOM of profile area (annotation band goes below this)
                // Sections are arranged top-to-bottom, so row 0 is at top.
                // Cell top: marginBottom + (RowsPerColumn-1-row) * totalCellH + annotation band
                // Cell profile bottom = cell top (of profile area, above band):
                double cellBottom = sheetOrigins[sheetIdx].Y + MarginBottom
                                    + (RowsPerColumn - 1 - row) * (totalCellH + GapVertical);
                double profileOriginY = cellBottom + AnnotationBandHeight;

                var layout = new CrossSectionLayout
                {
                    Data            = AllSections[i],
                    SheetX          = ox,
                    SheetY          = profileOriginY,
                    Width           = CellWidth,
                    Height          = CellProfileHeight,
                    HorizontalScale = 1.0 / HorizontalScale,
                    VerticalScale   = 1.0 / vEffDenom,
                    IsPlaced        = false
                };

                layouts.Add(layout);
                labelList.Add(AllSections[i].StationLabel);
                oxList.Add(ox);
                oyList.Add(profileOriginY);
                bandTopList.Add(profileOriginY);     // geometry node subtracts its own clearance
                sheetIdxList.Add(sheetIdx);
            }

            Layouts              = layouts;
            SheetOrigins         = sheetOrigins;
            StationLabels        = labelList;
            SectionOriginX       = oxList;
            SectionOriginY       = oyList;
            AnnotationBandTopY   = bandTopList;
            SectionSheetIndex    = sheetIdxList;

            return NodeUpdateResult.Success;
        }

        [Technique(Description = "Computes layout and checks that each section's design profile " +
                                 "actually fits within its profile cell (CellWidth × CellProfileHeight). " +
                                 "Returns a warning if any section overflows.")]
        public NodeUpdateResult ComputeLayoutWithFitCheck()
        {
            NodeUpdateResult result = ComputeLayout();
            if (!result.IsSuccess) return result;

            double vEffDenom = HorizontalScale / VerticalExaggerationFactor;
            var overflows = new List<string>();

            foreach (var layout in Layouts)
            {
                if (layout.Data.Points.Count < 2) continue;

                double extentH = (layout.Data.Points.Max(p => p.Offset)
                                 - layout.Data.Points.Min(p => p.Offset))
                                 / HorizontalScale;
                double extentV = (layout.Data.Points.Max(p => p.Elevation)
                                 - layout.Data.Points.Min(p => p.Elevation))
                                 / vEffDenom;

                if (extentH > CellWidth)
                    overflows.Add($"{layout.Data.StationLabel}: profile wider than cell " +
                                  $"({extentH:F1} > {CellWidth:F1})");
                if (extentV > CellProfileHeight)
                    overflows.Add($"{layout.Data.StationLabel}: profile taller than profile area " +
                                  $"({extentV:F1} > {CellProfileHeight:F1})");
            }

            if (overflows.Count > 0)
                return NodeUpdateResult.CustomWarning(
                    "Fit check warnings (adjust scale or cell size):\n" +
                    string.Join("\n", overflows));

            return NodeUpdateResult.Success;
        }
    }
}
