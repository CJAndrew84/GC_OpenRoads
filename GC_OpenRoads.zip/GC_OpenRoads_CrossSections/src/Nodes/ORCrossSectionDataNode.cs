// =============================================================================
//  Nodes/ORCrossSectionDataNode.cs
//
//  GC Node Type: "ORCrossSectionData"
//
//  PURPOSE
//  -------
//  The heart of the addon.  Calls OpenRoadsHelper.ExtractCrossSections() to
//  sample the corridor at user-defined station intervals and exposes:
//    • the full list of CrossSectionData objects for downstream use
//    • summary statistics (count, total cut volume, total fill volume)
//    • a CSV-formatted text report of all section points
//
//  This node is what drives GC's parametric capability: changing StartStation,
//  EndStation, or StationInterval causes GC to recompute the entire graph.
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.CifNET.GeometryModel.SDK;
using static GC_OpenRoads_CrossSections.Utilities.OpenRoadsHelper;
using GC_OpenRoads_CrossSections.Models;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORCrossSectionData",
        Category    = "OpenRoads|CrossSections",
        Description = "Samples an OpenRoads corridor at a given station interval " +
                      "and produces structured cross-section data for each station.")]
    public class ORCrossSectionDataNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "Corridor name to sample. Must exist in the active DGN.")]
        public string CorridorName
        {
            get => _corridorName;
            set { _corridorName = value; NotifyPropertyChanged(); }
        }
        private string _corridorName = string.Empty;

        [Input(Description =
            "Alignment name. When provided, the active terrain model is sampled at each " +
            "section station to populate ExistingElevation on every feature point. " +
            "This drives the Existing Level and Delta rows in the annotation band. " +
            "Must match the corridor's parent alignment name.")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        [Input(Description = "Start chainage for section extraction (metres). " +
                             "Leave 0 to start at the corridor's own start station.")]
        public double StartStation
        {
            get => _startStation;
            set { _startStation = value; NotifyPropertyChanged(); }
        }
        private double _startStation = 0.0;

        [Input(Description = "End chainage for section extraction (metres). " +
                             "Leave 0 to end at the corridor's own end station.")]
        public double EndStation
        {
            get => _endStation;
            set { _endStation = value; NotifyPropertyChanged(); }
        }
        private double _endStation = 0.0;

        [Input(Description = "Station interval between cross sections (metres). Default 10.")]
        public double StationInterval
        {
            get => _stationInterval;
            set { _stationInterval = Math.Max(value, 0.1); NotifyPropertyChanged(); }
        }
        private double _stationInterval = 10.0;

        [Input(Description = "Additional stations to always include (e.g. bridge abutments). " +
                             "Comma-separated, e.g. '1234.5, 1267.0'.")]
        public string ExtraStations
        {
            get => _extraStations;
            set { _extraStations = value; NotifyPropertyChanged(); }
        }
        private string _extraStations = string.Empty;

        // =====================================================================
        //  OUTPUTS
        // =====================================================================

        [Output(Description = "Extracted cross-section data, one entry per station.")]
        public IReadOnlyList<CrossSectionData> Sections { get; private set; }
            = Array.Empty<CrossSectionData>();

        [Output(Description = "Number of cross sections extracted.")]
        public int SectionCount { get; private set; }

        [Output(Description = "Total cut area summed across all sections (m²).")]
        public double TotalCutArea { get; private set; }

        [Output(Description = "Total fill area summed across all sections (m²).")]
        public double TotalFillArea { get; private set; }

        [Output(Description = "Approximate cut volume using the average-end-area method (m³).")]
        public double CutVolumeM3 { get; private set; }

        [Output(Description = "Approximate fill volume using the average-end-area method (m³).")]
        public double FillVolumeM3 { get; private set; }

        [Output(Description = "CSV text report of all section points.")]
        public string CsvReport { get; private set; } = string.Empty;

        [Output(Description = "Station labels for all extracted sections.")]
        public IReadOnlyList<string> StationLabels { get; private set; }
            = Array.Empty<string>();

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(Description = "Extracts cross-section data at a uniform station interval.")]
        public NodeUpdateResult ByInterval()
        {
            if (string.IsNullOrWhiteSpace(CorridorName))
                return NodeUpdateResult.CustomFailure("CorridorName is required.");

            Corridor? corridor = OpenRoadsHelper.FindCorridor(CorridorName);
            if (corridor == null)
                return NodeUpdateResult.CustomFailure(
                    $"Corridor '{CorridorName}' not found in the active model.");

            // Resolve station limits
            double start = StartStation > 0.0 ? StartStation : corridor.StartDistance;
            double end   = EndStation   > 0.0 ? EndStation   : corridor.EndDistance;

            if (start >= end)
                return NodeUpdateResult.CustomFailure(
                    $"StartStation ({start:F3}) must be less than EndStation ({end:F3}).");

            // Extract sections at interval
            // Resolve alignment for terrain sampling (null = no terrain sampling)
            var alignment = string.IsNullOrWhiteSpace(AlignmentName)
                ? null
                : OpenRoadsHelper.FindAlignment(AlignmentName);

            var sections = OpenRoadsHelper.ExtractCrossSections(
                corridor, start, end, StationInterval, alignment);

            // Merge any extra stations
            sections.AddRange(ParseExtraStations(corridor, start, end, alignment));
            sections = sections
                .OrderBy(s => s.Station)
                .DistinctBy(s => Math.Round(s.Station, 3))
                .ToList();

            Sections      = sections;
            SectionCount  = sections.Count;
            StationLabels = sections.Select(s => s.StationLabel).ToList();

            // Summaries
            TotalCutArea  = sections.Sum(s => s.CutArea);
            TotalFillArea = sections.Sum(s => s.FillArea);

            // Average-end-area volumes
            CutVolumeM3  = 0;
            FillVolumeM3 = 0;
            for (int i = 1; i < sections.Count; i++)
            {
                double dist = sections[i].Station - sections[i - 1].Station;
                CutVolumeM3  += 0.5 * (sections[i - 1].CutArea  + sections[i].CutArea)  * dist;
                FillVolumeM3 += 0.5 * (sections[i - 1].FillArea + sections[i].FillArea) * dist;
            }

            CsvReport = BuildCsvReport(sections);
            return NodeUpdateResult.Success;
        }

        [Technique(Description = "Extracts a single cross section at the specified station.")]
        public NodeUpdateResult AtStation(double station)
        {
            if (string.IsNullOrWhiteSpace(CorridorName))
                return NodeUpdateResult.CustomFailure("CorridorName is required.");

            Corridor? corridor = OpenRoadsHelper.FindCorridor(CorridorName);
            if (corridor == null)
                return NodeUpdateResult.CustomFailure(
                    $"Corridor '{CorridorName}' not found.");

            var alignmentForTerrain = string.IsNullOrWhiteSpace(AlignmentName)
                ? null
                : OpenRoadsHelper.FindAlignment(AlignmentName);
            var section = OpenRoadsHelper.ExtractCrossSectionAtStation(
                corridor, station, alignmentForTerrain);
            if (section == null)
                return NodeUpdateResult.CustomFailure(
                    $"Station {station:F3} is outside the corridor range " +
                    $"[{corridor.StartDistance:F3}, {corridor.EndDistance:F3}].");

            Sections      = new[] { section };
            SectionCount  = 1;
            StationLabels = new[] { section.StationLabel };
            TotalCutArea  = section.CutArea;
            TotalFillArea = section.FillArea;
            CutVolumeM3   = 0;
            FillVolumeM3  = 0;
            CsvReport     = BuildCsvReport(Sections);

            return NodeUpdateResult.Success;
        }

        // =====================================================================
        //  PRIVATE HELPERS
        // =====================================================================

        private List<CrossSectionData> ParseExtraStations(
            Corridor corridor, double start, double end,
            Alignment? alignmentForTerrain = null)
        {
            var result = new List<CrossSectionData>();
            if (string.IsNullOrWhiteSpace(ExtraStations)) return result;

            foreach (string part in ExtraStations.Split(',', StringSplitOptions.RemoveEmptyEntries))
            {
                if (double.TryParse(part.Trim(), out double sta) && sta >= start && sta <= end)
                {
                    var s = OpenRoadsHelper.ExtractCrossSectionAtStation(corridor, sta, alignmentForTerrain);
                    if (s != null) result.Add(s);
                }
            }
            return result;
        }

        private static string BuildCsvReport(IReadOnlyList<CrossSectionData> sections)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Station,StationLabel,FeatureName,PointCode,Offset,Elevation,CutFill");

            foreach (var section in sections)
            {
                foreach (var pt in section.Points)
                {
                    sb.AppendLine(string.Join(",",
                        section.Station.ToString("F3"),
                        $"\"{section.StationLabel}\"",
                        $"\"{pt.FeatureName}\"",
                        $"\"{pt.PointCode}\"",
                        pt.Offset.ToString("F4"),
                        pt.Elevation.ToString("F4"),
                        pt.CutFill.ToString("F4")));
                }
            }
            return sb.ToString();
        }
    }
}
