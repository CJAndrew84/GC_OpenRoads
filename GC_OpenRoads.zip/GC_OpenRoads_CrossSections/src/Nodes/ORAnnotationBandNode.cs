// =============================================================================
//  Nodes/ORAnnotationBandNode.cs
//
//  GC Node Type: "ORAnnotationBand"
//
//  PURPOSE
//  -------
//  Draws the tabular annotation box that sits directly below each cross-section
//  profile.  Each column aligns with a corridor feature point (CL, EOP_L, etc.),
//  and each row carries one data value type.
//
//  LAYOUT DIAGRAM
//  --------------
//
//   ┌────────────┬──────┬──────┬──────┬──────┬──────┬──────┐
//   │            │ PT_L │EOP_L │  CL  │EOP_R │ PT_R │ ...  │  ← column per feature point
//   ├────────────┼──────┼──────┼──────┼──────┼──────┼──────┤
//   │ Point Label│DAYLFT│EOP_L │  CL  │EOP_R │DAYRT │      │
//   ├────────────┼──────┼──────┼──────┼──────┼──────┼──────┤
//   │ Offset     │-15.23│-7.00 │ 0.000│ 7.000│ 16.45│      │
//   ├────────────┼──────┼──────┼──────┼──────┼──────┼──────┤
//   │ Proposed Lv│98.142│97.500│97.000│97.500│96.890│      │
//   ├────────────┼──────┼──────┼──────┼──────┼──────┼──────┤
//   │ Existing Lv│98.700│97.600│97.080│97.450│97.200│      │
//   ├────────────┼──────┼──────┼──────┼──────┼──────┼──────┤
//   │ Delta      │-0.558│-0.100│-0.080│ 0.050│-0.310│      │  ← user-enabled optional row
//   └────────────┴──────┴──────┴──────┴──────┴──────┴──────┘
//
//  COORDINATE SYSTEM
//  -----------------
//  BandTopY          — Y of the top edge of the box  (input from geometry node)
//  LabelColumnWidth  — width of the left-hand label column
//  Column widths     — driven by ColumnCentreX[] from the geometry node, so
//                      columns align exactly with the tick marks / drop lines above
//
//  ROW ORDER (top to bottom, matching the diagram)
//  ------------------------------------------------
//  The default order is: PointLabel, Offset, ProposedLevel, ExistingLevel.
//  Extra rows (Delta, CutFill, Custom…) are appended after the mandatory four,
//  in the order the user specifies via the EnableDeltaRow / ExtraRows inputs.
//  The user can also reorder by manipulating Rows directly in a Script Almighty node.
//
//  VERTICAL EXAGGERATION NOTE
//  --------------------------
//  The band itself is not affected by vertical exaggeration — it is always drawn
//  at its natural text/box sizes.  Only the profile above it uses VE.  The
//  ORCrossSectionSheetLayoutNode.AnnotationBandHeight input must be large enough
//  to hold all enabled rows.  The output TotalBandHeight helps the user validate
//  or drive that input.
// =============================================================================

using Bentley.DgnPlatformNET;
using Bentley.DgnPlatformNET.Elements;
using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.GeometryNET;
using Bentley.MstnPlatformNET;
using GC_OpenRoads_CrossSections.Models;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORAnnotationBand",
        Category    = "OpenRoads|CrossSections",
        Description =
            "Builds and places the tabular annotation band below a cross-section profile. " +
            "Mandatory rows: Point Label, Offset, Proposed Level, Existing Level. " +
            "Optional built-in rows: Delta (Δ), Cut/Fill. " +
            "Unlimited user-defined custom rows via ExtraRowKeys / ExtraRowLabels.")]
    public class ORAnnotationBandNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS — Data
        // =====================================================================

        [Input(Description = "Cross-section data for this section (from ORCrossSectionData node).")]
        public CrossSectionData? SectionData
        {
            get => _sectionData;
            set { _sectionData = value; NotifyPropertyChanged(); }
        }
        private CrossSectionData? _sectionData;

        [Input(Description =
            "X centre position for each feature point column, in sheet space. " +
            "Connect from ORCrossSectionGeometry.ColumnCentreX. " +
            "Must have the same count as SectionData.Points.")]
        public IReadOnlyList<double> ColumnCentreX
        {
            get => _colCentreX;
            set { _colCentreX = value; NotifyPropertyChanged(); }
        }
        private IReadOnlyList<double> _colCentreX = Array.Empty<double>();

        [Input(Description =
            "Y coordinate of the top edge of the annotation band. " +
            "Connect from ORCrossSectionGeometry.AnnotationBandTopY.")]
        public double BandTopY
        {
            get => _bandTopY;
            set { _bandTopY = value; NotifyPropertyChanged(); }
        }
        private double _bandTopY;

        [Input(Description =
            "X of the leftmost column left edge (= ProfileLeftX from geometry node).")]
        public double BandLeftX
        {
            get => _bandLeftX;
            set { _bandLeftX = value; NotifyPropertyChanged(); }
        }
        private double _bandLeftX;

        [Input(Description =
            "X of the rightmost column right edge (= ProfileRightX from geometry node).")]
        public double BandRightX
        {
            get => _bandRightX;
            set { _bandRightX = value; NotifyPropertyChanged(); }
        }
        private double _bandRightX;

        // =====================================================================
        //  INPUTS — Row configuration
        // =====================================================================

        [Input(Description = "Height of each data row in sheet master units. Default 5.")]
        public double RowHeight
        {
            get => _rowHeight;
            set { _rowHeight = Math.Max(value, 0.5); NotifyPropertyChanged(); }
        }
        private double _rowHeight = 5.0;

        [Input(Description = "Text height for data values in sheet master units. Default 2.5.")]
        public double TextHeight
        {
            get => _textHeight;
            set { _textHeight = Math.Max(value, 0.5); NotifyPropertyChanged(); }
        }
        private double _textHeight = 2.5;

        [Input(Description = "Text height for the left-hand row label column. Default 2.0.")]
        public double LabelTextHeight
        {
            get => _labelTextHeight;
            set { _labelTextHeight = Math.Max(value, 0.5); NotifyPropertyChanged(); }
        }
        private double _labelTextHeight = 2.0;

        [Input(Description =
            "Width of the left-hand label column in sheet master units. Default 20.")]
        public double LabelColumnWidth
        {
            get => _labelColW;
            set { _labelColW = Math.Max(value, 5); NotifyPropertyChanged(); }
        }
        private double _labelColW = 20.0;

        [Input(Description = "Numeric format string for level/offset values. Default 'F3' (3 d.p.).")]
        public string NumericFormat
        {
            get => _numFmt;
            set { _numFmt = value; NotifyPropertyChanged(); }
        }
        private string _numFmt = "F3";

        // =====================================================================
        //  INPUTS — Which built-in rows to include
        //
        //  The four mandatory rows (PointLabel, Offset, ProposedLevel,
        //  ExistingLevel) are always shown.  Toggle the extras below.
        // =====================================================================

        [Input(Description =
            "Show the 'Delta' row (Δ = Proposed Level − Existing Level). " +
            "Displayed as a signed value; negative means design is below existing ground.")]
        public bool EnableDeltaRow
        {
            get => _delta;
            set { _delta = value; NotifyPropertyChanged(); }
        }
        private bool _delta = false;

        [Input(Description = "Show the 'Cut/Fill' row (positive = cut, negative = fill). " +
                             "Sourced directly from corridor CorridorPoint.CutFill.")]
        public bool EnableCutFillRow
        {
            get => _cutFill;
            set { _cutFill = value; NotifyPropertyChanged(); }
        }
        private bool _cutFill = false;

        [Input(Description =
            "Comma-separated keys for extra custom rows, e.g. 'Grade,Superelevation,RoadLayer'. " +
            "Each key is looked up in CrossSectionPoint.CustomValues. " +
            "Must have the same count as ExtraRowLabels.")]
        public string ExtraRowKeys
        {
            get => _extraKeys;
            set { _extraKeys = value; NotifyPropertyChanged(); }
        }
        private string _extraKeys = string.Empty;

        [Input(Description =
            "Comma-separated display labels for each extra row, " +
            "e.g. 'Grade %,Superelevation %,Layer Thickness'. " +
            "Must match ExtraRowKeys count.")]
        public string ExtraRowLabels
        {
            get => _extraLabels;
            set { _extraLabels = value; NotifyPropertyChanged(); }
        }
        private string _extraLabels = string.Empty;

        [Input(Description =
            "Comma-separated numeric format strings for each extra row (one per extra row). " +
            "Use 'F3' for 3 decimal places, 'P1' for percentage, 'G' for general. " +
            "If fewer entries than rows, the global NumericFormat is used as fallback.")]
        public string ExtraRowFormats
        {
            get => _extraFmts;
            set { _extraFmts = value; NotifyPropertyChanged(); }
        }
        private string _extraFmts = string.Empty;

        [Input(Description =
            "Draw the outer border rectangle of the annotation box.")]
        public bool DrawOuterBorder
        {
            get => _outerBorder;
            set { _outerBorder = value; NotifyPropertyChanged(); }
        }
        private bool _outerBorder = true;

        [Input(Description =
            "Draw internal horizontal divider lines between rows.")]
        public bool DrawRowDividers
        {
            get => _rowDividers;
            set { _rowDividers = value; NotifyPropertyChanged(); }
        }
        private bool _rowDividers = true;

        [Input(Description =
            "Draw internal vertical divider lines between columns.")]
        public bool DrawColumnDividers
        {
            get => _colDividers;
            set { _colDividers = value; NotifyPropertyChanged(); }
        }
        private bool _colDividers = true;

        [Input(Description =
            "Draw the vertical line separating the label column from the data columns.")]
        public bool DrawLabelDivider
        {
            get => _labelDivider;
            set { _labelDivider = value; NotifyPropertyChanged(); }
        }
        private bool _labelDivider = true;

        // =====================================================================
        //  OUTPUTS — Computed geometry / metadata
        // =====================================================================

        [Output(Description = "Total height of the annotation band in sheet master units. " +
                              "Use this to set AnnotationBandHeight in the layout node.")]
        public double TotalBandHeight { get; private set; }

        [Output(Description = "Y of the bottom edge of the annotation band.")]
        public double BandBottomY { get; private set; }

        [Output(Description = "Number of rows that will be drawn (including all enabled rows).")]
        public int RowCount { get; private set; }

        [Output(Description = "Row labels in top-to-bottom order (for external wiring / validation).")]
        public IReadOnlyList<string> RowLabels { get; private set; }
            = Array.Empty<string>();

        [Output(Description = "Fully resolved annotation band result (for custom GC script use).")]
        public AnnotationBandResult? BandResult { get; private set; }

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(IsDefault = true,
                   Description =
                       "Computes the annotation band geometry and text. No DGN writes.")]
        public NodeUpdateResult Build()
        {
            var validation = ValidateInputs();
            if (!validation.IsSuccess) return validation;

            var rows = BuildRowDefinitions();
            var band = ComputeBandGeometry(rows);

            // Populate outputs
            TotalBandHeight = band.TotalHeight;
            BandBottomY     = BandTopY - band.TotalHeight;
            RowCount        = rows.Count;
            RowLabels       = rows.Select(r => r.Label).ToList();
            BandResult      = band;

            return NodeUpdateResult.Success;
        }

        [Technique(Description =
            "Computes the annotation band AND places all elements " +
            "(border lines, dividers, text) into the active DGN model.")]
        public NodeUpdateResult BuildAndPlace()
        {
            var buildResult = Build();
            if (!buildResult.IsSuccess) return buildResult;

            PlaceBandInDgn(BandResult!);
            return NodeUpdateResult.Success;
        }

        // =====================================================================
        //  ROW DEFINITION BUILDER
        // =====================================================================

        /// <summary>
        /// Assembles the ordered list of row definitions.
        /// Order (top to bottom in box):
        ///   1. Point Label     — always
        ///   2. Offset          — always
        ///   3. Proposed Level  — always
        ///   4. Existing Level  — always
        ///   5. Delta           — if EnableDeltaRow
        ///   6. Cut/Fill        — if EnableCutFillRow
        ///   7. Extra rows      — in the order given by ExtraRowKeys
        /// </summary>
        private List<AnnotationRowDefinition> BuildRowDefinitions()
        {
            var rows = new List<AnnotationRowDefinition>
            {
                new()
                {
                    Key             = "point_label",
                    Label           = "Point Label",
                    RowType         = AnnotationRowType.PointLabel,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Centre,
                    NumericFormat   = NumericFormat
                },
                new()
                {
                    Key             = "offset",
                    Label           = "Offset",
                    RowType         = AnnotationRowType.Offset,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat   = NumericFormat
                },
                new()
                {
                    Key             = "proposed_level",
                    Label           = "Proposed Level",
                    RowType         = AnnotationRowType.ProposedLevel,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat   = NumericFormat
                },
                new()
                {
                    Key             = "existing_level",
                    Label           = "Existing Level",
                    RowType         = AnnotationRowType.ExistingLevel,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat   = NumericFormat
                },
            };

            // Optional built-in rows
            if (EnableDeltaRow)
            {
                rows.Add(new()
                {
                    Key             = "delta",
                    Label           = "Δ (Prop − Exist)",
                    RowType         = AnnotationRowType.Delta,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat   = NumericFormat
                });
            }

            if (EnableCutFillRow)
            {
                rows.Add(new()
                {
                    Key             = "cutfill",
                    Label           = "Cut / Fill",
                    RowType         = AnnotationRowType.CutFill,
                    RowHeight       = RowHeight,
                    TextHeight      = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat   = NumericFormat
                });
            }

            // User-defined extra rows
            var extraKeys    = Split(ExtraRowKeys);
            var extraLabels  = Split(ExtraRowLabels);
            var extraFormats = Split(ExtraRowFormats);

            for (int i = 0; i < extraKeys.Count; i++)
            {
                string key   = extraKeys[i];
                string label = i < extraLabels.Count  ? extraLabels[i]  : key;
                string fmt   = i < extraFormats.Count ? extraFormats[i] : NumericFormat;

                rows.Add(new()
                {
                    Key               = key,
                    Label             = label,
                    RowType           = AnnotationRowType.Custom,
                    RowHeight         = RowHeight,
                    TextHeight        = TextHeight,
                    TextJustification = CellTextJustification.Right,
                    NumericFormat     = fmt
                });
            }

            return rows;
        }

        // =====================================================================
        //  GEOMETRY COMPUTATION
        // =====================================================================

        private AnnotationBandResult ComputeBandGeometry(List<AnnotationRowDefinition> rows)
        {
            var result = new AnnotationBandResult
            {
                Section        = SectionData!,
                LabelColumnWidth = LabelColumnWidth,
            };

            int nCols = SectionData!.Points.Count;
            double totalHeight = rows.Count * RowHeight;

            result.OriginX    = BandLeftX - LabelColumnWidth;
            result.OriginY    = BandTopY  - totalHeight;
            result.TotalWidth = (BandRightX - BandLeftX) + LabelColumnWidth;
            result.TotalHeight = totalHeight;

            // ----------------------------------------------------------------
            //  Column divider X positions
            //  The data area runs from BandLeftX to BandRightX.
            //  Each column occupies from mid-way between its neighbour and the
            //  next one, but for dividers we use the X values between columns.
            //  We place dividers at the midpoint between adjacent ColumnCentreX
            //  values, plus the two outer edges.
            // ----------------------------------------------------------------
            result.ColumnDividerX.Add(BandLeftX);      // left edge of data area

            for (int c = 0; c < nCols - 1; c++)
            {
                double mid = 0.5 * (ColumnCentreX[c] + ColumnCentreX[c + 1]);
                result.ColumnDividerX.Add(mid);
            }

            result.ColumnDividerX.Add(BandRightX);     // right edge of data area

            // ----------------------------------------------------------------
            //  Row divider Y positions (top of band downwards)
            // ----------------------------------------------------------------
            for (int r = 0; r <= rows.Count; r++)
            {
                result.RowDividerY.Add(BandTopY - r * RowHeight);
            }

            // ----------------------------------------------------------------
            //  Populate row data
            // ----------------------------------------------------------------
            for (int r = 0; r < rows.Count; r++)
            {
                var rowDef = rows[r];
                double rowTopY    = BandTopY - r * RowHeight;
                double rowBottomY = rowTopY  - RowHeight;
                double rowMidY    = 0.5 * (rowTopY + rowBottomY);

                var bandRow = new AnnotationBandRow
                {
                    Definition = rowDef,
                    TopY       = rowTopY,
                    BottomY    = rowBottomY,
                    LabelText  = rowDef.Label
                };

                // One cell per feature point column
                for (int c = 0; c < nCols; c++)
                {
                    var pt      = SectionData.Points[c];
                    double left = result.ColumnDividerX[c];
                    double right= result.ColumnDividerX[c + 1];

                    string cellText = ResolveCellText(rowDef, pt);

                    bandRow.Cells.Add(new AnnotationBandCell
                    {
                        ColumnIndex  = c,
                        Point        = pt,
                        Text         = cellText,
                        CellCentreX  = 0.5 * (left + right),
                        CellCentreY  = rowMidY
                    });
                }

                result.Rows.Add(bandRow);
            }

            return result;
        }

        // =====================================================================
        //  CELL TEXT RESOLVER
        // =====================================================================

        private string ResolveCellText(AnnotationRowDefinition rowDef, CrossSectionPoint pt)
        {
            try
            {
                return rowDef.RowType switch
                {
                    AnnotationRowType.PointLabel =>
                        string.IsNullOrEmpty(pt.PointCode)
                            ? pt.FeatureName
                            : pt.PointCode,

                    AnnotationRowType.Offset =>
                        pt.Offset.ToString(rowDef.NumericFormat),

                    AnnotationRowType.ProposedLevel =>
                        pt.Elevation.ToString(rowDef.NumericFormat),

                    AnnotationRowType.ExistingLevel =>
                        pt.ExistingElevation.HasValue
                            ? pt.ExistingElevation.Value.ToString(rowDef.NumericFormat)
                            : "—",

                    AnnotationRowType.Delta =>
                        pt.ExistingElevation.HasValue
                            ? (pt.Elevation - pt.ExistingElevation.Value)
                                  .ToString(rowDef.NumericFormat)
                            : "—",

                    AnnotationRowType.CutFill =>
                        pt.CutFill.ToString(rowDef.NumericFormat),

                    AnnotationRowType.Custom =>
                        ResolveCustomValue(rowDef, pt),

                    _ => string.Empty
                };
            }
            catch
            {
                return "ERR";
            }
        }

        private static string ResolveCustomValue(AnnotationRowDefinition rowDef, CrossSectionPoint pt)
        {
            // Priority 1: explicit delegate (set via Script Almighty node)
            if (rowDef.ValueProvider != null)
                return rowDef.ValueProvider(pt);

            // Priority 2: value stored in pt.CustomValues by key
            if (pt.CustomValues.TryGetValue(rowDef.Key, out string? val))
                return val ?? "—";

            return "—";
        }

        // =====================================================================
        //  DGN PLACEMENT
        // =====================================================================

        private void PlaceBandInDgn(AnnotationBandResult band)
        {
            DgnModel model       = Session.Instance.GetActiveDgnModel();
            DgnFile   dgnFile    = Session.Instance.GetActiveDgnFile();
            DgnTextStyle? tStyle = GetOrCreateTextStyle(dgnFile, "XS_Annotation", TextHeight);
            DgnTextStyle? lStyle = GetOrCreateTextStyle(dgnFile, "XS_Label",      LabelTextHeight);

            double boxLeft   = band.OriginX;
            double boxRight  = boxLeft + band.TotalWidth;
            double boxTop    = BandTopY;
            double boxBottom = BandTopY - band.TotalHeight;
            double dataLeft  = boxLeft + LabelColumnWidth;

            // ----------------------------------------------------------------
            //  Outer border
            // ----------------------------------------------------------------
            if (DrawOuterBorder)
            {
                PlaceRectangle(model,
                    boxLeft, boxBottom,
                    boxRight, boxTop);
            }

            // ----------------------------------------------------------------
            //  Label column divider
            // ----------------------------------------------------------------
            if (DrawLabelDivider)
            {
                PlaceLine(model, dataLeft, boxTop, dataLeft, boxBottom);
            }

            // ----------------------------------------------------------------
            //  Row content
            // ----------------------------------------------------------------
            foreach (var row in band.Rows)
            {
                // Horizontal row divider above this row (skip the topmost line —
                // that's the outer border top)
                if (DrawRowDividers && Math.Abs(row.TopY - boxTop) > 1e-6)
                {
                    PlaceLine(model, boxLeft, row.TopY, boxRight, row.TopY);
                }

                // Row label text (left-hand column, left-justified, vertically centred)
                double rowMidY = 0.5 * (row.TopY + row.BottomY);
                PlaceText(model, dgnFile,
                    row.LabelText,
                    boxLeft + 1.0,        // 1 unit left margin inside label cell
                    rowMidY,
                    lStyle,
                    TextJustification.LeftCenter);

                // ----------------------------------------------------------------
                //  Column content and vertical dividers
                // ----------------------------------------------------------------
                for (int c = 0; c < row.Cells.Count; c++)
                {
                    var cell      = row.Cells[c];
                    double cLeft  = band.ColumnDividerX[c];
                    double cRight = band.ColumnDividerX[c + 1];

                    // Vertical column divider on the left of this column
                    // (right divider of last column = outer border, already drawn)
                    if (DrawColumnDividers && c > 0)
                    {
                        PlaceLine(model, cLeft, boxTop, cLeft, boxBottom);
                    }

                    // Cell text
                    double textX = ResolveTextX(cell.Definition.TextJustification,
                                                cLeft, cRight);
                    var justif   = MapJustification(cell.Definition.TextJustification);
                    PlaceText(model, dgnFile,
                        cell.Text,
                        textX, rowMidY,
                        tStyle,
                        justif);
                }
            }

            // Bottom row divider (= outer border bottom, but only if border off)
            if (!DrawOuterBorder && DrawRowDividers)
            {
                PlaceLine(model, boxLeft, boxBottom, boxRight, boxBottom);
            }
        }

        // =====================================================================
        //  DGN ELEMENT HELPERS
        // =====================================================================

        private static void PlaceLine(DgnModel model,
            double x1, double y1, double x2, double y2)
        {
            var el = LineElement.Create(model, new DPoint3d(x1, y1, 0), new DPoint3d(x2, y2, 0));
            el.AddToModel();
        }

        private static void PlaceRectangle(DgnModel model,
            double left, double bottom, double right, double top)
        {
            var pts = new DPoint3d[]
            {
                new(left,  bottom, 0),
                new(right, bottom, 0),
                new(right, top,    0),
                new(left,  top,    0),
                new(left,  bottom, 0),  // close
            };
            var el = new LineStringElement(model, null, pts);
            el.AddToModel();
        }

        private static void PlaceText(DgnModel model, DgnFile dgnFile,
            string text, double x, double y,
            DgnTextStyle? style, TextJustification justif)
        {
            if (string.IsNullOrEmpty(text)) return;

            var origin    = new DPoint3d(x, y, 0);
            var textBlock = new TextElement(
                model,
                text,
                origin,
                style ?? DgnTextStyle.GetByName("Standard", dgnFile),
                justif);
            textBlock.AddToModel();
        }

        private static DgnTextStyle? GetOrCreateTextStyle(
            DgnFile dgnFile, string name, double height)
        {
            var existing = DgnTextStyle.GetByName(name, dgnFile);
            if (existing != null) return existing;

            // Build a minimal text style if the named one doesn't exist
            var style = new DgnTextStyle(name, dgnFile);
            style.SetProperty(TextStyleProperty.Height, height);
            style.SetProperty(TextStyleProperty.Width,  height * 0.8);
            // Add to file (transact if needed)
            return style;
        }

        private static double ResolveTextX(
            CellTextJustification justif, double left, double right)
            => justif switch
            {
                CellTextJustification.Left   => left  + 0.5,
                CellTextJustification.Right  => right - 0.5,
                _                            => 0.5 * (left + right)
            };

        private static TextJustification MapJustification(CellTextJustification j)
            => j switch
            {
                CellTextJustification.Left  => TextJustification.LeftCenter,
                CellTextJustification.Right => TextJustification.RightCenter,
                _                           => TextJustification.CenterCenter
            };

        // =====================================================================
        //  VALIDATION + UTILITIES
        // =====================================================================

        private NodeUpdateResult ValidateInputs()
        {
            if (SectionData == null || SectionData.Points.Count == 0)
                return NodeUpdateResult.CustomFailure(
                    "SectionData is null or empty.");

            if (ColumnCentreX == null || ColumnCentreX.Count == 0)
                return NodeUpdateResult.CustomFailure(
                    "ColumnCentreX is empty. Connect from ORCrossSectionGeometry.ColumnCentreX.");

            if (ColumnCentreX.Count != SectionData.Points.Count)
                return NodeUpdateResult.CustomFailure(
                    $"ColumnCentreX has {ColumnCentreX.Count} entries but SectionData has " +
                    $"{SectionData.Points.Count} points. These must match.");

            // Validate extra row key / label parity
            var keys   = Split(ExtraRowKeys);
            var labels = Split(ExtraRowLabels);
            if (keys.Count > 0 && labels.Count > 0 && keys.Count != labels.Count)
                return NodeUpdateResult.CustomFailure(
                    $"ExtraRowKeys has {keys.Count} entries but ExtraRowLabels has " +
                    $"{labels.Count}. They must match (or ExtraRowLabels can be empty " +
                    $"to use keys as labels).");

            return NodeUpdateResult.Success;
        }

        private static List<string> Split(string csv)
        {
            if (string.IsNullOrWhiteSpace(csv)) return new List<string>();
            return csv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                      .ToList();
        }
    }
}
