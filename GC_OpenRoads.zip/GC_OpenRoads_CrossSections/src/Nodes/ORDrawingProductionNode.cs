// =============================================================================
//  Nodes/ORDrawingProductionNode.cs
//
//  GC Node Type: "ORDrawingProduction"
//
//  PURPOSE
//  -------
//  Top-level orchestration node.  Ties together:
//    • Cross-section data extraction (from ORCrossSectionDataNode)
//    • Named boundary placement (from ORNamedBoundaryNode)
//    • Sheet model creation via ORD's Drawing Production API
//    • Annotation group assignment
//
//  The user connects this node's outputs to the ORCrossSectionSheetLayout node
//  which handles the actual GC geometry placement on each sheet.
//
//  DRAWING PRODUCTION FLOW (mirrors the manual ORD workflow):
//    1.  Open/create a cross-section base file (XSEC_bas)
//    2.  Attach design references (corridor, terrain, geometry)
//    3.  Place Named Boundaries at all section stations
//    4.  Run "Create Drawing" to generate one drawing model per section
//    5.  Run "Annotate" to apply the annotation group
//    6.  Optionally place into sheet models with a title block
// =============================================================================

using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using GC_OpenRoads_CrossSections.Models;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORDrawingProduction",
        Category    = "OpenRoads|DrawingProduction",
        Description = "Orchestrates the full cross-section drawing production pipeline: " +
                      "data extraction → named boundaries → drawing models → annotation.")]
    public class ORDrawingProductionNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "Alignment name to drive the production run.")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        [Input(Description = "Corridor name to extract section geometry from.")]
        public string CorridorName
        {
            get => _corridorName;
            set { _corridorName = value; NotifyPropertyChanged(); }
        }
        private string _corridorName = string.Empty;

        [Input(Description = "Start chainage (metres). 0 = use alignment start.")]
        public double StartStation
        {
            get => _start;
            set { _start = value; NotifyPropertyChanged(); }
        }
        private double _start = 0.0;

        [Input(Description = "End chainage (metres). 0 = use alignment end.")]
        public double EndStation
        {
            get => _end;
            set { _end = value; NotifyPropertyChanged(); }
        }
        private double _end = 0.0;

        [Input(Description = "Station interval (metres). Default 10.")]
        public double StationInterval
        {
            get => _interval;
            set { _interval = Math.Max(value, 0.1); NotifyPropertyChanged(); }
        }
        private double _interval = 10.0;

        [Input(Description = "Left offset for named boundaries (metres from CL).")]
        public double LeftOffset
        {
            get => _leftOffset;
            set { _leftOffset = value; NotifyPropertyChanged(); }
        }
        private double _leftOffset = 20.0;

        [Input(Description = "Right offset for named boundaries (metres from CL).")]
        public double RightOffset
        {
            get => _rightOffset;
            set { _rightOffset = value; NotifyPropertyChanged(); }
        }
        private double _rightOffset = 20.0;

        [Input(Description = "Drawing seed name from workspace DGNLIB.")]
        public string DrawingSeedName
        {
            get => _seedName;
            set { _seedName = value; NotifyPropertyChanged(); }
        }
        private string _seedName = "Cross Section";

        [Input(Description = "Annotation group name to apply to drawing models.")]
        public string AnnotationGroupName
        {
            get => _annotGroup;
            set { _annotGroup = value; NotifyPropertyChanged(); }
        }
        private string _annotGroup = string.Empty;

        [Input(Description = "Number of cross sections to place per sheet column.")]
        public int SectionsPerColumn
        {
            get => _perColumn;
            set { _perColumn = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private int _perColumn = 4;

        [Input(Description = "Number of columns per sheet.")]
        public int ColumnsPerSheet
        {
            get => _perSheet;
            set { _perSheet = Math.Max(value, 1); NotifyPropertyChanged(); }
        }
        private int _perSheet = 2;

        // =====================================================================
        //  OUTPUTS
        // =====================================================================

        [Output(Description = "All cross-section data extracted from the corridor.")]
        public IReadOnlyList<CrossSectionData> AllSections { get; private set; }
            = Array.Empty<CrossSectionData>();

        [Output(Description = "Total number of cross sections in this production run.")]
        public int SectionCount { get; private set; }

        [Output(Description = "Number of sheets that will be (or were) produced.")]
        public int SheetCount { get; private set; }

        [Output(Description = "Approximate total cut volume (m³) across all sections.")]
        public double TotalCutVolumeM3 { get; private set; }

        [Output(Description = "Approximate total fill volume (m³) across all sections.")]
        public double TotalFillVolumeM3 { get; private set; }

        [Output(Description = "Named boundary settings object for downstream layout node.")]
        public NamedBoundarySettings BoundarySettings { get; private set; } = new();

        [Output(Description = "Status message from the production run.")]
        public string ProductionStatus { get; private set; } = string.Empty;

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(Description = "Validates inputs and computes section count / sheet count " +
                                 "without modifying the DGN. Use for planning.")]
        public NodeUpdateResult Preview()
        {
            var (corridor, error) = ResolveCorridorAndAlignment();
            if (corridor == null)
                return NodeUpdateResult.CustomFailure(error!);

            double start = StartStation > 0 ? StartStation : corridor.StartDistance;
            double end   = EndStation   > 0 ? EndStation   : corridor.EndDistance;

            var sections = OpenRoadsHelper.ExtractCrossSections(
                corridor, start, end, StationInterval);

            PopulateOutputs(sections, start, end);
            ProductionStatus = $"Preview: {SectionCount} sections on {SheetCount} sheet(s). " +
                               $"Cut: {TotalCutVolumeM3:N0} m³  Fill: {TotalFillVolumeM3:N0} m³";

            return NodeUpdateResult.Success;
        }

        [Technique(Description = "Runs the full drawing production pipeline: places Named " +
                                 "Boundaries, creates drawing models, and applies annotations.")]
        public NodeUpdateResult RunFullProduction()
        {
            // Step 1: Preview / extract data
            NodeUpdateResult previewResult = Preview();
            if (!previewResult.IsSuccess) return previewResult;

            // Step 2: Place Named Boundaries via keyin
            try
            {
                string keyin = $"PLACE NAMED BOUNDARY CIVIL CROSS SECTION " +
                               $"ALIGNMENT \"{AlignmentName}\" " +
                               $"START {BoundarySettings.StartStation:F3} " +
                               $"END {BoundarySettings.EndStation:F3} " +
                               $"INTERVAL {BoundarySettings.StationInterval:F3} " +
                               $"LEFT {BoundarySettings.LeftOffset:F3} " +
                               $"RIGHT {BoundarySettings.RightOffset:F3} " +
                               $"SEED \"{BoundarySettings.DrawingSeedName}\"";

                Bentley.MstnPlatformNET.Session.Instance.RunKeyin(keyin);
            }
            catch (Exception ex)
            {
                return NodeUpdateResult.CustomFailure(
                    $"Failed to place Named Boundaries: {ex.Message}");
            }

            // Step 3: Create drawings
            try
            {
                Bentley.MstnPlatformNET.Session.Instance.RunKeyin(
                    "DRAWING PRODUCTION CREATE DRAWINGS CROSS SECTION");
            }
            catch (Exception ex)
            {
                return NodeUpdateResult.CustomFailure(
                    $"Failed to create drawing models: {ex.Message}");
            }

            // Step 4: Apply annotation group (optional)
            if (!string.IsNullOrWhiteSpace(AnnotationGroupName))
            {
                try
                {
                    Bentley.MstnPlatformNET.Session.Instance.RunKeyin(
                        $"DRAWING PRODUCTION ANNOTATE GROUP \"{AnnotationGroupName}\"");
                }
                catch (Exception ex)
                {
                    // Non-fatal: log but continue
                    ProductionStatus += $" [Annotation warning: {ex.Message}]";
                }
            }

            ProductionStatus = $"Production complete: {SectionCount} sections, " +
                               $"{SheetCount} sheets. " +
                               $"Cut: {TotalCutVolumeM3:N0} m³  Fill: {TotalFillVolumeM3:N0} m³";

            return NodeUpdateResult.Success;
        }

        // =====================================================================
        //  PRIVATE HELPERS
        // =====================================================================

        private (Bentley.CifNET.GeometryModel.SDK.Corridor? corridor, string? error)
            ResolveCorridorAndAlignment()
        {
            if (string.IsNullOrWhiteSpace(AlignmentName))
                return (null, "AlignmentName is required.");
            if (string.IsNullOrWhiteSpace(CorridorName))
                return (null, "CorridorName is required.");

            var al = OpenRoadsHelper.FindAlignment(AlignmentName);
            if (al == null)
                return (null, $"Alignment '{AlignmentName}' not found.");

            var cor = OpenRoadsHelper.FindCorridor(CorridorName);
            if (cor == null)
                return (null, $"Corridor '{CorridorName}' not found.");

            return (cor, null);
        }

        private void PopulateOutputs(
            List<CrossSectionData> sections,
            double start, double end)
        {
            AllSections  = sections;
            SectionCount = sections.Count;
            SheetCount   = (int)Math.Ceiling(
                               (double)SectionCount / (SectionsPerColumn * ColumnsPerSheet));

            // Average-end-area volumes
            double cut = 0, fill = 0;
            for (int i = 1; i < sections.Count; i++)
            {
                double dist = sections[i].Station - sections[i - 1].Station;
                cut  += 0.5 * (sections[i - 1].CutArea  + sections[i].CutArea)  * dist;
                fill += 0.5 * (sections[i - 1].FillArea + sections[i].FillArea) * dist;
            }
            TotalCutVolumeM3  = cut;
            TotalFillVolumeM3 = fill;

            BoundarySettings = new NamedBoundarySettings
            {
                AlignmentName   = AlignmentName,
                StartStation    = start,
                EndStation      = end,
                StationInterval = StationInterval,
                LeftOffset      = LeftOffset,
                RightOffset     = RightOffset,
                DrawingSeedName = DrawingSeedName
            };
        }
    }
}
