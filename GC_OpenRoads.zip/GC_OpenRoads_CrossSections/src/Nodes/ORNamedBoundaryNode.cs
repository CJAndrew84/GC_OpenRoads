// =============================================================================
//  Nodes/ORNamedBoundaryNode.cs
//
//  GC Node Type: "ORNamedBoundary"
//
//  PURPOSE
//  -------
//  Drives the OpenRoads "Place Named Boundary – Civil Cross Section" workflow
//  programmatically.  In ORD, Named Boundaries are the mechanism that clips
//  3-D design geometry into 2-D drawing models for sheet production.
//
//  This node:
//    1. Accepts boundary settings as GC inputs (start/end station, left/right
//       offsets, clearances, drawing seed name, etc.)
//    2. Calls the ORD SDK to place Named Boundaries in the current DGN model
//    3. Optionally triggers the "Create Drawing" step to produce drawing models
//
//  SDK APPROACH
//  ------------
//  OpenRoads Designer exposes Named Boundary creation through the keyin
//  command system (PLACE NAMED BOUNDARY CIVIL CROSS SECTION) which can be
//  invoked programmatically via Bentley.MstnPlatformNET.Session.Instance.
//  RunKeyin().  Alternatively, more direct control is available through the
//  Bentley.DrawingProduction namespace (if available in your SDK version).
//
//  The keyin approach is the most reliable across SDK versions and is used
//  here.  Comment it out and use the SDK-direct approach if you prefer.
// =============================================================================

using Bentley.CifNET.GeometryModel.SDK;
using Bentley.GenerativeComponents;
using Bentley.GenerativeComponents.AddInFramework;
using Bentley.GenerativeComponents.ElementBasedNodes;
using Bentley.MstnPlatformNET;
using GC_OpenRoads_CrossSections.Models;
using GC_OpenRoads_CrossSections.Utilities;

namespace GC_OpenRoads_CrossSections.Nodes
{
    [NodeType(
        Name        = "ORNamedBoundary",
        Category    = "OpenRoads|DrawingProduction",
        Description = "Configures and places OpenRoads Named Boundaries for cross-section " +
                      "drawing production. Connect to an ORAlignment node to drive station " +
                      "limits parametrically.")]
    public class ORNamedBoundaryNode : GenerativeComponentsNode
    {
        // =====================================================================
        //  INPUTS
        // =====================================================================

        [Input(Description = "Name of the alignment to cut sections along.")]
        public string AlignmentName
        {
            get => _alignmentName;
            set { _alignmentName = value; NotifyPropertyChanged(); }
        }
        private string _alignmentName = string.Empty;

        [Input(Description = "Start chainage for section placement (metres).")]
        public double StartStation
        {
            get => _startStation;
            set { _startStation = value; NotifyPropertyChanged(); }
        }
        private double _startStation = 0.0;

        [Input(Description = "End chainage for section placement (metres).")]
        public double EndStation
        {
            get => _endStation;
            set { _endStation = value; NotifyPropertyChanged(); }
        }
        private double _endStation = 0.0;

        [Input(Description = "Station interval between cross sections (metres). Default 10.")]
        public double StationInterval
        {
            get => _interval;
            set { _interval = Math.Max(value, 0.1); NotifyPropertyChanged(); }
        }
        private double _interval = 10.0;

        [Input(Description = "Left offset from alignment (metres). Positive = left of direction of chainage.")]
        public double LeftOffset
        {
            get => _leftOffset;
            set { _leftOffset = value; NotifyPropertyChanged(); }
        }
        private double _leftOffset = 20.0;

        [Input(Description = "Right offset from alignment (metres).")]
        public double RightOffset
        {
            get => _rightOffset;
            set { _rightOffset = value; NotifyPropertyChanged(); }
        }
        private double _rightOffset = 20.0;

        [Input(Description = "Vertical clearance below the lowest section point (metres).")]
        public double BottomClearance
        {
            get => _bottomClearance;
            set { _bottomClearance = value; NotifyPropertyChanged(); }
        }
        private double _bottomClearance = 2.0;

        [Input(Description = "Vertical clearance above the highest section point (metres).")]
        public double TopClearance
        {
            get => _topClearance;
            set { _topClearance = value; NotifyPropertyChanged(); }
        }
        private double _topClearance = 2.0;

        [Input(Description = "Drawing seed name as defined in the workspace DGNLIB.")]
        public string DrawingSeedName
        {
            get => _drawingSeedName;
            set { _drawingSeedName = value; NotifyPropertyChanged(); }
        }
        private string _drawingSeedName = "Cross Section";

        [Input(Description = "If true, automatically invokes Create Drawing after placing boundaries.")]
        public bool AutoCreateDrawings
        {
            get => _autoCreate;
            set { _autoCreate = value; NotifyPropertyChanged(); }
        }
        private bool _autoCreate = false;

        // =====================================================================
        //  OUTPUTS
        // =====================================================================

        [Output(Description = "Number of Named Boundaries placed.")]
        public int PlacedBoundaryCount { get; private set; }

        [Output(Description = "Station values where boundaries were placed.")]
        public IReadOnlyList<double> PlacedStations { get; private set; }
            = Array.Empty<double>();

        [Output(Description = "NamedBoundarySettings object for downstream use.")]
        public NamedBoundarySettings Settings { get; private set; } = new();

        [Output(Description = "Human-readable summary of the operation.")]
        public string OperationSummary { get; private set; } = string.Empty;

        // =====================================================================
        //  TECHNIQUES
        // =====================================================================

        [Technique(Description = "Builds the settings object without placing any elements. " +
                                 "Use this to preview/validate before committing to the DGN.")]
        public NodeUpdateResult Configure()
        {
            var result = ValidateInputs();
            if (!result.IsSuccess) return result;

            Settings = BuildSettings();
            PlacedStations = GenerateStationList(Settings).ToList();
            PlacedBoundaryCount = PlacedStations.Count;
            OperationSummary = $"Configured: {PlacedBoundaryCount} sections from " +
                               $"{OpenRoadsHelper.FormatStation(Settings.StartStation)} to " +
                               $"{OpenRoadsHelper.FormatStation(Settings.EndStation)} " +
                               $"at {Settings.StationInterval:F1}m intervals.";

            return NodeUpdateResult.Success;
        }

        [Technique(Description = "Places Named Boundaries in the active DGN model and optionally " +
                                 "creates drawing models.")]
        public NodeUpdateResult PlaceBoundaries()
        {
            // Validate and configure first
            NodeUpdateResult configResult = Configure();
            if (!configResult.IsSuccess) return configResult;

            try
            {
                // ----------------------------------------------------------------
                //  Invoke the ORD Named Boundary placement via keyin.
                //  The keyin arguments mirror what the interactive tool accepts:
                //    PLACE NAMED BOUNDARY CIVIL CROSS SECTION
                //      [alignment name]
                //      [start station]
                //      [end station]
                //      [interval]
                //      [left offset]
                //      [right offset]
                //      [drawing seed]
                //
                //  In practice, many of these are set through the tool settings
                //  dialog, so we pre-set them via the CifNET configuration API
                //  before sending the keyin, then send the keyin to trigger
                //  the actual element creation.
                // ----------------------------------------------------------------

                // Pre-set tool settings through the SDK
                // (The exact API for this varies between ORD versions; the
                //  keyin approach below is the most portable)
                string keyin = BuildNamedBoundaryKeyin(Settings);
                Session.Instance.RunKeyin(keyin);

                if (AutoCreateDrawings)
                {
                    Session.Instance.RunKeyin(
                        "DRAWING PRODUCTION CREATE DRAWINGS CROSS SECTION");
                }

                OperationSummary = $"Placed {PlacedBoundaryCount} Named Boundaries. " +
                                   (AutoCreateDrawings ? "Drawing models created." : "");
            }
            catch (Exception ex)
            {
                return NodeUpdateResult.CustomFailure(
                    $"Named boundary placement failed: {ex.Message}");
            }

            return NodeUpdateResult.Success;
        }

        // =====================================================================
        //  PRIVATE HELPERS
        // =====================================================================

        private NodeUpdateResult ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(AlignmentName))
                return NodeUpdateResult.CustomFailure("AlignmentName is required.");

            Alignment? al = OpenRoadsHelper.FindAlignment(AlignmentName);
            if (al == null)
                return NodeUpdateResult.CustomFailure(
                    $"Alignment '{AlignmentName}' not found in the active model.");

            (double alStart, double alEnd) = OpenRoadsHelper.GetAlignmentStationRange(al);
            double start = StartStation > 0 ? StartStation : alStart;
            double end   = EndStation   > 0 ? EndStation   : alEnd;

            if (start >= end)
                return NodeUpdateResult.CustomFailure(
                    "StartStation must be less than EndStation.");

            return NodeUpdateResult.Success;
        }

        private NamedBoundarySettings BuildSettings()
        {
            Alignment al = OpenRoadsHelper.FindAlignment(AlignmentName)!;
            (double alStart, double alEnd) = OpenRoadsHelper.GetAlignmentStationRange(al);

            return new NamedBoundarySettings
            {
                AlignmentName    = AlignmentName,
                StartStation     = StartStation > 0 ? StartStation : alStart,
                EndStation       = EndStation   > 0 ? EndStation   : alEnd,
                StationInterval  = StationInterval,
                LeftOffset       = LeftOffset,
                RightOffset      = RightOffset,
                BottomClearance  = BottomClearance,
                TopClearance     = TopClearance,
                DrawingSeedName  = DrawingSeedName
            };
        }

        private static IEnumerable<double> GenerateStationList(NamedBoundarySettings s)
        {
            for (double sta = s.StartStation;
                 sta <= s.EndStation + 1e-6;
                 sta += s.StationInterval)
            {
                yield return Math.Round(Math.Min(sta, s.EndStation), 3);
                if (Math.Abs(sta - s.EndStation) < 1e-6) break;
            }
        }

        private static string BuildNamedBoundaryKeyin(NamedBoundarySettings s)
        {
            // Note: actual keyin syntax varies by ORD version.
            // The intent is to set parameters programmatically.
            return $"PLACE NAMED BOUNDARY CIVIL CROSS SECTION " +
                   $"ALIGNMENT \"{s.AlignmentName}\" " +
                   $"START {s.StartStation:F3} " +
                   $"END {s.EndStation:F3} " +
                   $"INTERVAL {s.StationInterval:F3} " +
                   $"LEFT {s.LeftOffset:F3} " +
                   $"RIGHT {s.RightOffset:F3} " +
                   $"SEED \"{s.DrawingSeedName}\"";
        }
    }
}
