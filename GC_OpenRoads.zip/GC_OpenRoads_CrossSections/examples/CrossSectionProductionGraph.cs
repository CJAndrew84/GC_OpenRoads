// =============================================================================
//  Example GC Script: Cross-Section Drawing Production with Annotation Bands
//  File: examples/CrossSectionProductionGraph.cs
//
//  Demonstrates:
//    • Vertical scale exaggeration (independent H / V scales)
//    • Annotation band with mandatory + optional + custom rows
//    • AnnotationBandHeight driving the sheet layout node
//    • Injecting ValueProvider delegates for derived custom rows
//
//  Paste into a GC Script Almighty node, or load as a transaction file.
// =============================================================================

// ─── Step 1: Alignment ────────────────────────────────────────────────────────
var alignment = Node<ORAlignmentNode>("Alignment")
{
    AlignmentName = "MAINRD_HA_01",
};

// ─── Step 2: Corridor ─────────────────────────────────────────────────────────
var corridor = Node<ORCorridorNode>("Corridor")
{
    AlignmentName = alignment.AlignmentName,
};

// ─── Step 3: Cross-section data + terrain sampling ────────────────────────────
//  AlignmentName here enables terrain sampling → populates ExistingElevation
//  on every CrossSectionPoint, which feeds Existing Level and Delta rows.
var sectionData = Node<ORCrossSectionDataNode>("SectionData")
{
    CorridorName    = corridor.ResolvedCorridorName,
    AlignmentName   = alignment.AlignmentName,
    StartStation    = alignment.StartStation,
    EndStation      = alignment.EndStation,
    StationInterval = 20.0,
    ExtraStations   = "",
};

// ─── Step 4: Pre-calculate annotation band height for layout ──────────────────
//
//  ANNOTATION BOX STRUCTURE (top → bottom)
//  ─────────────────────────────────────────
//  ┌────────────┬──────┬──────┬──────┬──────┬──────┐
//  │ Point Label│PT_L  │EOP_L │  CL  │EOP_R │PT_R  │   ← always
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Offset     │-15.23│-7.000│ 0.000│ 7.000│16.450│   ← always
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Proposed Lv│98.142│97.500│97.000│97.500│96.890│   ← always
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Existing Lv│98.700│97.600│97.080│97.450│97.200│   ← always
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Δ          │-0.558│-0.100│-0.080│ 0.050│-0.310│   ← optional (EnableDeltaRow)
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Cut / Fill │ 0.558│ 0.100│ 0.080│-0.050│ 0.310│   ← optional (EnableCutFillRow)
//  ├────────────┼──────┼──────┼──────┼──────┼──────┤
//  │ Grade %    │  2.30│  1.50│  0.00│  1.50│  2.30│   ← custom (ExtraRowKeys)
//  └────────────┴──────┴──────┴──────┴──────┴──────┘

double rowHeight    = 5.0;
int    mandatoryRows = 4;
bool   showDelta    = true;
bool   showCutFill  = true;
int    extraRows    = 1;     // Grade %

int    totalRows    = mandatoryRows
                    + (showDelta   ? 1 : 0)
                    + (showCutFill ? 1 : 0)
                    + extraRows;
double totalBandH   = totalRows * rowHeight;   // e.g. 7 × 5 = 35

// ─── Step 5: Sheet layout ─────────────────────────────────────────────────────
//
//  SCALE MODEL
//  ───────────
//  HorizontalScaleDenominator  = 200  →  H 1:200
//  VerticalExaggerationFactor  = 2.0  →  effective V denom = 100  (V 1:100)
//
//  AnnotationBandHeight = totalBandH reserves space below each profile cell
//  so annotation boxes never overlap the profile drawn above.

var layout = Node<ORCrossSectionSheetLayoutNode>("Layout")
{
    AllSections                = sectionData.Sections,
    SheetWidth                 = 594.0,
    SheetHeight                = 420.0,
    ColumnsPerSheet            = 2,
    RowsPerColumn              = 4,
    MarginLeft                 = 20.0,
    MarginRight                = 20.0,
    MarginTop                  = 30.0,
    MarginBottom               = 20.0,
    GapHorizontal              = 10.0,
    GapVertical                = 10.0,
    HorizontalScale            = 200.0,
    VerticalExaggerationFactor = 2.0,
    AnnotationBandHeight       = totalBandH,
};

Print($"Sheets required : {layout.TotalSheets}");
Print($"Profile cell    : {layout.CellWidth:F1} × {layout.CellProfileHeight:F1}");
Print($"Band reserved   : {layout.AnnotationBandHeight:F1} ({totalRows} rows × {rowHeight})");

// ─── Step 6: Per-section nodes ────────────────────────────────────────────────
for (int i = 0; i < sectionData.SectionCount; i++)
{
    // ── 6a. Profile geometry ────────────────────────────────────────────────
    //
    //  VerticalExaggerationFactor = 2.0 makes the profile draw at V 1:100
    //  while horizontal remains 1:200.  The ScaleLabel output gives a
    //  ready-made string to put on the drawing: "H 1:200  /  V 1:100  (×2 V.E.)"
    var geom = Node<ORCrossSectionGeometryNode>($"Geom_{i:D3}")
    {
        SectionData                = sectionData.Sections[i],
        AlignmentName              = alignment.AlignmentName,
        HorizontalScaleDenominator = layout.HorizontalScale,
        VerticalExaggerationFactor = layout.VerticalExaggerationFactor,
        OriginX                    = layout.SectionOriginX[i],
        OriginY                    = layout.SectionOriginY[i],
        ProfileBottomClearance     = 2.0,
        TickHalfHeight             = 1.0,
        DrawDatumLine              = true,
        DrawVerticalDropLines      = true,
    };
    // Evaluate Build2DProfile() — no DGN writes yet.
    // Switch to PlaceInDgn() to write to the active model.

    // ── 6b. Annotation band ─────────────────────────────────────────────────
    //
    //  ColumnCentreX and AnnotationBandTopY come from the geometry node so
    //  annotation columns align exactly with the tick marks / drop lines above.
    var band = Node<ORAnnotationBandNode>($"Band_{i:D3}")
    {
        SectionData        = sectionData.Sections[i],

        // Wired from geometry node — ensures pixel-perfect column alignment
        ColumnCentreX      = geom.ColumnCentreX,
        BandTopY           = geom.AnnotationBandTopY,
        BandLeftX          = geom.ProfileLeftX,
        BandRightX         = geom.ProfileRightX,

        // Row sizing — must match the pre-calculation above
        RowHeight          = rowHeight,
        TextHeight         = 2.5,
        LabelTextHeight    = 2.0,
        LabelColumnWidth   = 20.0,
        NumericFormat      = "F3",

        // Mandatory rows: Point Label, Offset, Proposed Level, Existing Level
        // are always included — no toggle needed.

        // Optional built-in rows
        EnableDeltaRow     = showDelta,
        EnableCutFillRow   = showCutFill,

        // Custom rows: key = lookup key in CrossSectionPoint.CustomValues
        //              label = text in the left-hand label cell
        //              format = numeric format string
        ExtraRowKeys       = "Grade",
        ExtraRowLabels     = "Grade %",
        ExtraRowFormats    = "F2",

        // Grid lines
        DrawOuterBorder    = true,
        DrawRowDividers    = true,
        DrawColumnDividers = true,
        DrawLabelDivider   = true,
    };
    // Call Build() to compute geometry without DGN writes.
    // Call BuildAndPlace() to write box, dividers and text to the active model.

    // Validate on first section
    if (i == 0)
    {
        Print($"\nSection 0 — {sectionData.Sections[0].StationLabel}");
        Print($"  Scale label  : {geom.ScaleLabel}");
        Print($"  Profile W×H  : {geom.ProfileWidth:F1} × {geom.ProfileHeight:F1}");
        Print($"  Band top Y   : {band.BandTopY:F2}");
        Print($"  Band bottom Y: {band.BandBottomY:F2}");
        Print($"  Band height  : {band.TotalBandHeight:F1} (expected {totalBandH:F1})");
        Print($"  Row order    : {string.Join(" | ", band.RowLabels)}");

        if (band.TotalBandHeight > layout.AnnotationBandHeight + 0.01)
            Print("  ⚠ Band taller than reserved space — " +
                  "increase AnnotationBandHeight in layout node.");
    }
}

// ─── Step 7: Drawing Production (ORD side) ────────────────────────────────────
//  Connect this to drive ORD Named Boundaries + Create Drawing.
var production = Node<ORDrawingProductionNode>("DrawingProduction")
{
    AlignmentName       = alignment.AlignmentName,
    CorridorName        = corridor.ResolvedCorridorName,
    StartStation        = alignment.StartStation,
    EndStation          = alignment.EndStation,
    StationInterval     = sectionData.StationInterval,
    LeftOffset          = 25.0,
    RightOffset         = 25.0,
    DrawingSeedName     = "Cross Section ANSI D",
    AnnotationGroupName = "",         // set to your workspace annotation group
    SectionsPerColumn   = layout.RowsPerColumn,
    ColumnsPerSheet     = layout.ColumnsPerSheet,
};
// Call Preview() to inspect section count / sheet count without modifying DGN.
// Call RunFullProduction() to place Named Boundaries and create drawing models.

Print($"\nTotal cut  : {sectionData.CutVolumeM3:N0} m³");
Print($"Total fill : {sectionData.FillVolumeM3:N0} m³");
Print($"CSV report : {sectionData.CsvReport.Length} chars " +
      $"({sectionData.SectionCount} sections × points)");

// =============================================================================
//  ADVANCED: Injecting a derived custom row via ValueProvider delegate
//
//  If your custom row value isn't stored in CrossSectionPoint.CustomValues
//  (e.g. it's a computed value from other fields), set ValueProvider on a
//  manually-built AnnotationRowDefinition after Build() completes:
//
//  // Width-from-CL row — absolute offset
//  var widthRow = new AnnotationRowDefinition
//  {
//      Key           = "WidthCL",
//      Label         = "Width from CL",
//      RowType       = AnnotationRowType.Custom,
//      RowHeight     = 5.0,
//      TextHeight    = 2.5,
//      NumericFormat = "F2",
//      ValueProvider = pt => Math.Abs(pt.Offset).ToString("F2"),
//  };
//  // Add key to ExtraRowKeys / ExtraRowLabels, then the node's Build()
//  // will call ValueProvider per cell (ValueProvider takes priority over
//  // CustomValues lookup).
//
//  // Superelevation (%) from CustomValues populated by corridor SDK extension:
//  //   pt.CustomValues["Superelevation"] = crossFall.ToString("F2");
//  // Then just set ExtraRowKeys = "...,Superelevation"
//  //           ExtraRowLabels  = "...,Superelevation %"
// =============================================================================
