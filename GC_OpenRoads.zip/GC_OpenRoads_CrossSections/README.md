# GC OpenRoads Cross-Section Addon
## A GenerativeComponents Addon for OpenRoads Designer Drawing Production

---

## Overview

This addon connects **Bentley GenerativeComponents (GC)** to the **OpenRoads Designer (ORD) SDK** to enable fully parametric cross-section drawing production. Instead of manually stepping through ORD's Named Boundary and Drawing Production wizards each time the design changes, you build a **GC graph** that automatically re-extracts section data, re-computes sheet layouts, and re-drives drawing creation whenever corridor or alignment parameters change.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     GC Transaction Model                            │
│                                                                     │
│  ORAlignmentNode ──────────────────────────────────────────────┐   │
│         │ (AlignmentName, StartStation, EndStation)             │   │
│         ▼                                                       │   │
│  ORCorridorNode ─────────────────────────────────────────────┐ │   │
│         │ (CorridorName)                                       │ │   │
│         ▼                                                       │ │   │
│  ORCrossSectionDataNode                                         │ │   │
│         │ (Sections[], SectionCount, Cut/FillVolumes, CSV)     │ │   │
│         │                                                       │ │   │
│    ┌────┴────────────────┐                                     │ │   │
│    ▼                     ▼                                     │ │   │
│  ORCrossSectionGeometryNode   ORCrossSectionSheetLayoutNode ◄──┘ │   │
│  (per-section 2D geometry)    (Layouts[], SheetOrigins, XY[])    │   │
│    │                               │                             │   │
│    └──────────────┬────────────────┘                             │   │
│                   ▼                                              │   │
│         ORNamedBoundaryNode ◄────────────────────────────────────┘   │
│                   │                                                  │
│                   ▼                                                  │
│         ORDrawingProductionNode                                      │
│         (end-to-end orchestration + keyin execution)                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Node Reference

### 1. ORAlignmentNode
**Category:** OpenRoads | Geometry  
**Purpose:** Selects and exposes a horizontal alignment from the active DGN.

| Property | Direction | Type | Description |
|---|---|---|---|
| `AlignmentName` | Input | string | Name as shown in ORD Properties panel |
| `StartStation` | Output | double | Alignment start chainage (m) |
| `EndStation` | Output | double | Alignment end chainage (m) |
| `Length` | Output | double | Total alignment length (m) |
| `AvailableAlignments` | Output | string[] | All alignments in active model |

**Techniques:**  
- `ByName()` — resolves alignment from name  
- `ByNameWithStationOverride(customStart, customEnd)` — limits to a sub-range

---

### 2. ORCorridorNode
**Category:** OpenRoads | Geometry  
**Purpose:** Resolves a corridor by name or by its parent alignment.

| Property | Direction | Type | Description |
|---|---|---|---|
| `CorridorName` | Input | string | Explicit corridor name (optional) |
| `AlignmentName` | Input | string | Finds first corridor on this alignment |
| `ResolvedCorridorName` | Output | string | Confirmed corridor name |
| `StartStation` | Output | double | Corridor start (m) |
| `EndStation` | Output | double | Corridor end (m) |

---

### 3. ORCrossSectionDataNode
**Category:** OpenRoads | CrossSections  
**Purpose:** Samples the corridor at a station interval and returns structured cross-section data.

| Property | Direction | Type | Description |
|---|---|---|---|
| `CorridorName` | Input | string | Corridor to sample |
| `StartStation` | Input | double | First section chainage |
| `EndStation` | Input | double | Last section chainage |
| `StationInterval` | Input | double | Spacing between sections (m) |
| `ExtraStations` | Input | string | Comma-separated extra chainages |
| `Sections` | Output | CrossSectionData[] | One per station |
| `SectionCount` | Output | int | How many sections were extracted |
| `TotalCutArea` | Output | double | Sum of cut areas (m²) |
| `TotalFillArea` | Output | double | Sum of fill areas (m²) |
| `CutVolumeM3` | Output | double | Average-end-area cut volume (m³) |
| `FillVolumeM3` | Output | double | Average-end-area fill volume (m³) |
| `CsvReport` | Output | string | Full point data as CSV text |

**Techniques:**  
- `ByInterval()` — main technique, uniform spacing  
- `AtStation(station)` — single section at a specific chainage

---

### 4. ORCrossSectionGeometryNode
**Category:** OpenRoads | CrossSections  
**Purpose:** Converts a single CrossSectionData record into 2-D GC geometry for drawing or preview.

| Property | Direction | Type | Description |
|---|---|---|---|
| `SectionData` | Input | CrossSectionData | From data node |
| `AlignmentName` | Input | string | For world-coord transform |
| `HorizontalScale` | Input | double | Scale denominator (e.g. 200) |
| `VerticalScale` | Input | double | Scale denominator for Z |
| `OriginX` / `OriginY` | Input | double | Sheet position of section |
| `DesignProfilePoints` | Output | DPoint3d[] | 2-D polyline points |
| `AnnotationTickPoints` | Output | DPoint3d[] | Leader line points |
| `AnnotationLabels` | Output | string[] | Feature point codes |
| `AnnotationOffsets` | Output | double[] | X offsets for label positioning |

**Techniques:**  
- `Build2DProfile()` — computes geometry, no DGN writes  
- `PlaceInDgn()` — places LineStringElement into active model

---

### 5. ORNamedBoundaryNode
**Category:** OpenRoads | DrawingProduction  
**Purpose:** Drives the ORD Named Boundary placement tool programmatically.

| Property | Direction | Type | Description |
|---|---|---|---|
| `AlignmentName` | Input | string | Target alignment |
| `StartStation` / `EndStation` | Input | double | Station range |
| `StationInterval` | Input | double | Boundary spacing |
| `LeftOffset` / `RightOffset` | Input | double | Section width from CL |
| `BottomClearance` / `TopClearance` | Input | double | Vertical clearance |
| `DrawingSeedName` | Input | string | Seed from workspace DGNLIB |
| `AutoCreateDrawings` | Input | bool | Trigger Create Drawing step |
| `PlacedBoundaryCount` | Output | int | Number of boundaries placed |
| `PlacedStations` | Output | double[] | Actual station values |
| `Settings` | Output | NamedBoundarySettings | For downstream use |

**Techniques:**  
- `Configure()` — preview/validate without DGN changes  
- `PlaceBoundaries()` — writes boundaries and optionally creates drawings

---

### 6. ORDrawingProductionNode
**Category:** OpenRoads | DrawingProduction  
**Purpose:** End-to-end orchestration — data extraction, boundary placement, drawing creation, annotation.

| Property | Direction | Type | Description |
|---|---|---|---|
| `AlignmentName` | Input | string | Drive alignment |
| `CorridorName` | Input | string | Corridor to slice |
| `StartStation` / `EndStation` | Input | double | Range |
| `StationInterval` | Input | double | Spacing |
| `AnnotationGroupName` | Input | string | ORD annotation group |
| `SectionsPerColumn` | Input | int | Layout control |
| `ColumnsPerSheet` | Input | int | Layout control |
| `AllSections` | Output | CrossSectionData[] | All extracted data |
| `SheetCount` | Output | int | Sheets required |
| `TotalCutVolumeM3` | Output | double | Total cut (m³) |
| `TotalFillVolumeM3` | Output | double | Total fill (m³) |

**Techniques:**  
- `Preview()` — read-only, no DGN changes  
- `RunFullProduction()` — full pipeline execution

---

### 7. ORCrossSectionSheetLayoutNode
**Category:** OpenRoads | DrawingProduction  
**Purpose:** Parametric sheet layout engine — arranges sections into columns, rows and sheets.

| Property | Direction | Type | Description |
|---|---|---|---|
| `AllSections` | Input | CrossSectionData[] | From data node |
| `SheetWidth` / `SheetHeight` | Input | double | Sheet size (master units) |
| `ColumnsPerSheet` / `RowsPerColumn` | Input | int | Grid definition |
| `MarginLeft/Right/Top/Bottom` | Input | double | Page margins |
| `GapHorizontal` / `GapVertical` | Input | double | Inter-section spacing |
| `HorizontalScale` / `VerticalScale` | Input | double | Drawing scales |
| `Layouts` | Output | CrossSectionLayout[] | One per section |
| `TotalSheets` | Output | int | Number of sheets |
| `CellWidth` / `CellHeight` | Output | double | Section cell dimensions |
| `SectionOriginX` / `SectionOriginY` | Output | double[] | Sheet coordinates |

**Techniques:**  
- `ComputeLayout()` — pure computation  
- `ComputeLayoutWithFitCheck()` — also validates sections fit in cells

---

## Setup Instructions

### 1. Prerequisites
- **OpenRoads Designer 2024** (or equivalent CONNECT Edition version)
- **GenerativeComponents CONNECT Edition** (standalone or embedded in ORD/OBD)
- **Visual Studio 2022** Community or higher
- **.NET 6.0** SDK

### 2. Build the Project

```bash
# Clone / copy project files to your working folder
cd GC_OpenRoads_CrossSections

# Edit the .csproj to point to YOUR installation paths:
#   <ORDInstallDir>C:\Program Files\Bentley\OpenRoads Designer 2024.00\OpenRoadsDesigner\</ORDInstallDir>
#   <GCInstallDir>C:\Program Files\Bentley\OpenBuildings GenerativeComponents 2024\...</GCInstallDir>

dotnet build -c Release
```

The output DLL is `bin\Release\net6.0-windows\GC_OpenRoads_CrossSections.dll`.

### 3. Register with GC

Option A (recommended): Use GC's **C# Project Generator** to set up a proper project  
structure, then copy/paste the node source files in.

Option B: Drop the built DLL into GC's AddIn folder:
```
%APPDATA%\Bentley\GenerativeComponents\CE\AddIns\
```
GC scans this folder on startup and loads any DLL containing a class decorated with `[AddIn]`.

### 4. Load a GC Graph

1. Open OpenRoads Designer (GC is embedded, or launch standalone GC)
2. Open a DGN file that contains an alignment and corridor
3. Switch to the **GC workflow** or launch GC from the ribbon
4. In the node browser, look for the **OpenRoads** category
5. Place an **ORAlignment** node and type your alignment name
6. Chain subsequent nodes as shown in the architecture diagram above

---

## Typical GC Graph for Cross-Section Sheets

```
ORAlignmentNode("MainRoad")
    .AlignmentName = "MAINRD_HA_01"
    ↓
ORCorridorNode
    .AlignmentName ← ORAlignmentNode.AlignmentName
    ↓
ORCrossSectionDataNode
    .CorridorName  ← ORCorridorNode.ResolvedCorridorName
    .StartStation  ← ORAlignmentNode.StartStation
    .EndStation    ← ORAlignmentNode.EndStation
    .StationInterval = 10.0   ← change this to reflow all sheets
    ↓
ORCrossSectionSheetLayoutNode
    .AllSections   ← ORCrossSectionDataNode.Sections
    .SheetWidth    = 594
    .SheetHeight   = 420
    .ColumnsPerSheet = 2
    .RowsPerColumn   = 4
    .HorizontalScale = 200
    .VerticalScale   = 200
    ↓
(For each section, GC replicates:)
ORCrossSectionGeometryNode[i]
    .SectionData  ← ORCrossSectionDataNode.Sections[i]
    .OriginX      ← ORCrossSectionSheetLayoutNode.SectionOriginX[i]
    .OriginY      ← ORCrossSectionSheetLayoutNode.SectionOriginY[i]
    ↓ Calls PlaceInDgn()
    ↓ DGN contains geometry
```

Then connect an **ORDrawingProductionNode** to run the ORD side (Named Boundaries + Create Drawing).

---

## Data Model Reference

### CrossSectionPoint
```
FeatureName   — corridor feature (e.g. "Carriageway")
PointCode     — template point code (e.g. "CL", "EOP_L", "DAYLIGHT_R")
Offset        — lateral offset from CL in metres (negative = left)
Elevation     — absolute elevation in metres
CutFill       — positive = cut, negative = fill
```

### CrossSectionData
```
Station       — chainage in metres
StationLabel  — formatted string, e.g. "1+234.567"
Points[]      — list of CrossSectionPoints sorted left-to-right
CutArea       — computed cut area (m²)
FillArea      — computed fill area (m²)
```

---

## SDK Version Notes

| SDK Version | Notes |
|---|---|
| CifNET SDK v1 (CONNECT Edition) | `corridor.GetSectionPoints(station)` |
| CifNET SDK v2 (ORD 2024) | May require `GetSectionPoints(station, SectionPointType.All)` |
| GC CONNECT Edition | Uses `[AddIn]`, `[NodeType]`, `[Technique]` attribute registration |
| GC earlier versions | May need `IGCAddIn` interface instead of `AddIn` base class |

If the `GetSectionPoints()` call is not available in your version, use the terrain
intersection approach: cast a vertical plane at the station through the corridor
element and collect intersection points using `Corridor.IntersectSectionPlane()`.

---

## Extending the Addon

- **Add terrain profiles:** Query `TerrainModel` for the DTM elevation at each section offset and add `TerrainPoints` to the `CrossSectionData`
- **Earthworks tables:** Wire `CutVolumeM3` / `FillVolumeM3` into GC text nodes to auto-populate the earthworks summary table on the title block
- **Custom annotation:** Create a GC node that drives `DgnTextElement` placement to annotate point codes and elevations at each feature point
- **Superelevation data:** Extend `CrossSectionPoint` with a `CrossFall` field, queried via `SuperElevation.GetCrossFallAtStation()`

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| Node shows "Alignment not found" | Name mismatch | Check ORD Properties → Feature Name (not Display Name) |
| `GetSectionPoints` throws | Station outside corridor range | Ensure `StartStation`/`EndStation` are within the corridor |
| Named boundaries don't place | Keyin syntax varies by version | Check ORD message centre; adjust keyin string in `ORNamedBoundaryNode` |
| DLL not loaded by GC | Wrong AddIn folder or wrong .NET target | Confirm `net6.0-windows` matches the GC host runtime |
| Empty `AvailableAlignments` | No CifNET connection | Open a DGN with civil data before activating the node |

---

*Built against: OpenRoads Designer 2024 SDK / GC CONNECT Edition / .NET 6.0*  
*Reference: Bentley CifNET SDK Help, GC API Documentation*
